function initializeTemp0gc1438a9d1874e() {
    FlexContainer0c2e98671ba7c46 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "22px",
        "id": "FlexContainer0c2e98671ba7c46",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer0c2e98671ba7c46.setDefaultUnit(kony.flex.DP);
    var Label0b6efa2098a924c = new kony.ui.Label({
        "id": "Label0b6efa2098a924c",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslLabel0j734cc84340741",
        "text": "Open",
        "top": "1%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0a70152e628354f = new kony.ui.Label({
        "height": "90%",
        "id": "CopyLabel0a70152e628354f",
        "isVisible": true,
        "left": "40%",
        "skin": "CopyslLabel0j734cc84340741",
        "text": "999",
        "top": "1%",
        "width": "2%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0c2e98671ba7c46.add(Label0b6efa2098a924c, CopyLabel0a70152e628354f);
}