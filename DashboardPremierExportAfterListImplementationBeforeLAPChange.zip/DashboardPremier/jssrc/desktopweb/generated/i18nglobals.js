kony.globals["appid"] = "DashboardPremier";
kony.globals["locales"] = [];