function initializesegRowTemp() {
    flxRowTemp = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "36px",
        "id": "flxRowTemp",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0jd37455f395240"
    }, {}, {});
    flxRowTemp.setDefaultUnit(kony.flex.DP);
    var lblTicket = new kony.ui.RichText({
        "id": "lblTicket",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslRichText0fcb80b59f34944",
        "text": "<a href=\"www.gmail.com\">987987</a>",
        "top": "30%",
        "width": "7%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblSeverity = new kony.ui.Label({
        "id": "lblSeverity",
        "isVisible": true,
        "left": "8%",
        "skin": "CopyslLabel0a5cdb363c29647",
        "text": "Severity",
        "top": "30%",
        "width": "8%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblStatus = new kony.ui.Label({
        "id": "lblStatus",
        "isVisible": true,
        "left": "16%",
        "skin": "CopyslLabel0a5cdb363c29647",
        "text": "Status",
        "top": "30%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCustName = new kony.ui.Label({
        "id": "lblCustName",
        "isVisible": true,
        "left": "26%",
        "skin": "CopyslLabel0h95819d826394d",
        "text": "Customer",
        "top": "30%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblCreated = new kony.ui.Label({
        "id": "lblCreated",
        "isVisible": true,
        "left": "46%",
        "skin": "CopyslLabel0ifedbe520f3e48",
        "text": "Created Date",
        "top": "30%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPsAssignee = new kony.ui.Label({
        "id": "lblPsAssignee",
        "isVisible": true,
        "left": "56%",
        "skin": "CopyslLabel0d963f7fc75b648",
        "text": "Assignee",
        "top": "30%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblDynamic = new kony.ui.Label({
        "id": "lblDynamic",
        "isVisible": true,
        "left": "76%",
        "skin": "CopyslLabel0d963f7fc75b648",
        "text": "Assignee",
        "top": "30%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxRowTemp.add(lblTicket, lblSeverity, lblStatus, lblCustName, lblCreated, lblPsAssignee, lblDynamic);
}