//Type your code here
clProblemStatementCseArr = [];
clCustomerDiscussionCseArr = [];
clSlaCseArr = [];
clProblemStatementProductArr = [];
clCustomerDiscussionProductArr = [];
clSlaProductArr = [];
clProblemStatementCloudArr = [];
clCustomerDiscussionCloudArr = [];
clSlaCloudArr = [];
clSJCseArr = [];
clSJProductArr = [];
clSJCloudArr = [];
// clPSCseCount=0;
// clPsProductCount=0;
// clPsCloudCount=0;
tempPsCse = [];
tempPsProdut = [];
tempPsCloud = [];

function setCommentsForSelectedCustomer() {
    tempPsCse = returnSelectedCustomerCommentsArr(clProblemStatementCseArr);
    tempPsProduct = returnSelectedCustomerCommentsArr(clProblemStatementProductArr);
    tempPsCloud = returnSelectedCustomerCommentsArr(clProblemStatementCloudArr);
    tempCdCse = returnSelectedCustomerCommentsArr(clCustomerDiscussionCseArr);
    tempCdProduct = returnSelectedCustomerCommentsArr(clCustomerDiscussionProductArr);
    tempCdCloud = returnSelectedCustomerCommentsArr(clCustomerDiscussionCloudArr);
    tempSlaCse = returnSelectedCustomerCommentsArr(clSlaCseArr);
    tempSlaProduct = returnSelectedCustomerCommentsArr(clSlaProductArr);
    tempSlaCloud = returnSelectedCustomerCommentsArr(clSlaCloudArr);
    tempSJCse = returnSelectedCustomerCommentsArr(clSJCseArr);
    tempSJProduct = returnSelectedCustomerCommentsArr(clSJProductArr);
    tempSJCloud = returnSelectedCustomerCommentsArr(clSJCloudArr);
    frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCse.lblPSCse1.text = tempPsCse.length;
    frmDashboard.flxLeadIndicator.flxSLAList.flxSLACse.lblSLACse1.text = tempSlaCse.length;
    frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCse.lblCDCse1.text = tempCdCse.length;
    frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCse.lblSJCse1.text = tempSJCse.length;
    frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementProduct.lblPSProduct1.text = tempPsProduct.length;
    frmDashboard.flxLeadIndicator.flxSLAList.flxSLAProduct.lblSLAProduct1.text = tempSlaProduct.length;
    frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDProduct.lblCDProduct1.text = tempCdProduct.length;
    frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJProduct.lblSJProduct1.text = tempSJProduct.length;
    frmDashboard.flxQualityIndicators.flxProblemStatementList.flxProblemStatementCloud.lblPSCloud1.text = tempPsCloud.length;
    frmDashboard.flxQualityIndicators.flxCustomerDiscussionList.flxCDCloud.lblCDCloud1.text = tempCdCloud.length;
    frmDashboard.flxSLAList.flxSLACloud.lblSLACloud1.text = tempSlaCloud.length;
    frmDashboard.flxQualityIndicators.flxSeverityJustificationList.flxSJCloud.lblSJCloud1.text = tempSJCloud.length;
    frmDashboard.flxQualityIndicators.flxProblemStatement.lblProblemStatementCount.text = tempPsCse.length + tempPsProduct.length + tempPsCloud.length;
    frmDashboard.flxSLA.lblSLACount.text = tempSlaCse.length + tempSlaProduct.length + tempCdCloud.length;
    frmDashboard.flxQualityIndicators.flxCustomerDiscussion.lblCustomerDiscussionCount.text = tempCdCse.length + tempCdProduct.length + tempCdCloud.length;
    frmDashboard.flxQualityIndicators.flxSeverityJustification.lblSeverityJustificationCount.text = tempSJCse.length + tempSJProduct.length + tempSJCloud.length;
    speedometer();
    ProblemStatementPopupCse = tempPsCse;
    ProblemStatementPopupProduct = tempPsProduct;
    ProblemStatementPopupCloud = tempPsCloud;
    customerDiscussionPopupCse = tempCdCse;
    customerDiscussionPopupProduct = tempCdProduct;
    customerDiscussionPopupCloud = tempCdCloud;
    ticketsForSLACse = tempSlaCse;
    ticketsForSLAProduct = tempSlaProduct;
    ticketsForSLACloud = tempSlaCloud;
    severityJustificationPopupCse = tempSJCse;
    severityJustificationPopupProduct = tempSJProduct;
    severityJustificationPopupCloud = tempSJCloud;
    //   for(var i=0;i<clProblemStatementCseArr.length;i++)
    //     {
    //       if(clProblemStatementCseArr[i].CName === selectedCustomer)
    //         {
    //           tempPsCse.push(clProblemStatementCseArr[i]);
    //           clPSCseCount++;
    //         }
    //     }
    //    for(var k=0;k<clProblemStatementCseArr.length;k++)
    //     {
    //       if(clProblemStatementCseArr[k].CName === selectedCustomer)
    //         {
    //           tempPsCse.push(clProblemStatementCseArr[k]);
    //           clPsProductCount++;
    //         }
    //     }
    //    for(var l=0;l<clProblemStatementCseArr.length;l++)
    //     {
    //       if(clProblemStatementCseArr[l].CName === selectedCustomer)
    //         {
    //           tempPsCse.push(clProblemStatementCseArr[l]);
    //           clPsCloudCount++;
    //         }
    //     }
}

function returnSelectedCustomerCommentsArr(arr) {
    temp = [];
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].CName === selectedCustomer || arr[i].CAccountName === selectedCustomer) {
            temp.push(arr[i].ticketId);
        }
    }
    return temp;
}

function initializePS() {
    tempPsCse = [];
    tempPsProdut = [];
    tempPsCloud = [];
    clProblemStatementCseArr = [];
    clCustomerDiscussionCseArr = [];
    clSlaCseArr = [];
    clProblemStatementProductArr = [];
    clCustomerDiscussionProductArr = [];
    clSlaProductArr = [];
    clProblemStatementCloudArr = [];
    clCustomerDiscussionCloudArr = [];
    clSlaCloudArr = [];
}