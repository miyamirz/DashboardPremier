//Type your code here
var a = "a";
var b = "b";
var c = "c";
var d = "d";
var e = "e";
var L2AutoSolvedCount = 0;
var L3AutoSolvedCount = 0;
var L2AutoSolvedArr = [];
var L3AutoSolvedArr = [];
var autoSolvedL3 = [];
var autoSolvedL2 = [];

function autoSolvedSuccess(res) {
    if (res.ticketsCount !== "0") {
        for (var m = 0; m < res.tickets.length; m++) {
            var customArr = res.tickets[m].CustomField;
            for (var z = 0; z < customArr.length; z++) {
                if (customArr[z].id === 21277110) {
                    custName = customArr[z].value;
                } else if (customArr[z].id === 21062879) {
                    custAcc = customArr[z].value;
                }
            }
            if (custName !== null) CustomerName = custName.trim();
            else CustomerName = "none";
            if (custAcc !== null) CustomerAccountName = custAcc.trim();
            else CustomerAccountName = "none";
            var id = res.tickets[m].AssigneeId;
            if (selectedCustomer === "All") {
                if (id === 235456932) {
                    autoSolvedL3.push(res.tickets[m]);
                    L3AutoSolvedCount++;
                    L3AutoSolvedArr.push(res.tickets[m]);
                } else {
                    autoSolvedL2.push(res.tickets[m]);
                    L2AutoSolvedCount++;
                    L2AutoSolvedArr.push(res.tickets[m]);
                }
            } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
                if (id === 235456932) {
                    autoSolvedL3.push(res.tickets[m]);
                    L3AutoSolvedCount++;
                    L3AutoSolvedArr.push(res.tickets[m]);
                } else {
                    autoSolvedL2.push(res.tickets[m]);
                    L2AutoSolvedCount++;
                    L2AutoSolvedArr.push(res.tickets[m]);
                }
            }
        }
    }
    if (selectedCustomer === "All") {
        fillIndicatorsCse();
        fillIndicatorsProduct();
        kony.timer.schedule(b, fillIndicatorsCloud, 30, false);
        kony.timer.schedule(c, rootCauseCloud, 25, false);
        severityJustificationCse();
        severityJustificationProduct();
        kony.timer.schedule(d, severityJustificationCloud, 40, false);
    } else {
        setCommentsForSelectedCustomer();
        setRcCommentsForSelectedCustomer();
    }
    frmDashboard.flxIndicators.flxLeadIndicator.flxAutoClosureList.flxAC0.lblAC02.text = L2AutoSolvedCount;
    frmDashboard.flxIndicators.flxLeadIndicator.flxAutoClosureList.flxAC1.lblAC12.text = L3AutoSolvedCount;
    var k = L2AutoSolvedCount + L3AutoSolvedCount;
    frmDashboard.flxLeadIndicator.flxAutoClosure.lblAutoSolvedCount.text = k;
}

function autoSolvedError(res) {
    kony.application.dismissLoadingScreen();
    //alert("Error in autoSolved response"); 
    frmDashboard.flxIndicators.opacity = 1;
}