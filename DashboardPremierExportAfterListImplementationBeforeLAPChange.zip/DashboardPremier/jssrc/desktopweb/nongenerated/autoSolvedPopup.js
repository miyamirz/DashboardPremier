//Type your code here//Type your code here
function showAutoSolvedPopup(context) {
    var flxId = context.constructorList[0].id;
    var i;
    frmDashboard.flxPopupLead.segPopupLead.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        slblDynamic: "slblDynamic",
        slblStatus: "slblStatus",
        lblTicket: "valId",
        lblSeverity: "Severity",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee",
        lblDynamic: "PSAssignee2",
        lblStatus: "Status"
    };
    arrToSetSegData = [
        [{
            slblTicket: "Ticket Id",
            slblSupportPlan: "Support Plan",
            slblSeverity: "Severity",
            slblCustName: "Customer Name",
            slblCreated: "Age(Days)",
            slblUpdated: "UpdatedAt",
            slblPsAssignee: "CSE Assignee",
            slblStatus: "Status",
        }, ]
    ];
    switch (flxId) {
        case "flxAC0":
            if (autoSolvedL2.length !== 0) {
                arrToSetSegData[0][0].slblDynamic = "Assignee";
                for (i = 0; i < autoSolvedL2.length; i++) {
                    if (autoSolvedL2[i].AssigneeId === 14272801548) {
                        assigneeKind = "BDE";
                    } else {
                        assigneeKind = "CSE";
                    }
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = autoSolvedL2[i].ticketId;
                    autoSolvedL2[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = autoSolvedL2[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                    }
                    if (ETA !== null && ETA !== "") {
                        autoSolvedL2[i].ETA = ETA.toString();
                    } else {
                        autoSolvedL2[i].ETA = "";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (assigneeKind === "BDE") {
                        PSAssignee = psAssign2.trim();
                        PSAssignee2 = "Kony BDE Product Support";
                    } else {
                        PSAssignee = psAssign.trim();
                        PSAssignee2 = "Kony Product Support";
                    }
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    autoSolvedL2[i].CName = CustomerName;
                    autoSolvedL2[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.trim();
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets" || second !== "Bde") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    autoSolvedL2[i].PSAssignee = PSAssignee;
                    autoSolvedL2[i].PSAssignee2 = PSAssignee2;
                    autoSolvedL2[i].Severity = severity;
                    var createdTime = autoSolvedL2[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = autoSolvedL2[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    autoSolvedL2[i].days = days;
                    //                                          openCse.tickets[i].CreatedAt=createdDateTime;
                    //                                          openCse.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(autoSolvedL2);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
        case "flxAC1":
            if (autoSolvedL3.length !== 0) {
                arrToSetSegData[0][0].slblDynamic = "ETA";
                for (i = 0; i < autoSolvedL3.length; i++) {
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = autoSolvedL3[i].ticketId;
                    autoSolvedL3[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = autoSolvedL3[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                        //  kony.print("iteration count in inner for loop:"+k);
                    }
                    if (ETA !== null && ETA !== "") {
                        autoSolvedL3[i].PSAssignee2 = ETA.toString();
                    } else {
                        autoSolvedL3[i].PSAssignee2 = "-";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (psAssign2 === "") {
                        PSAssignee = psAssign.trim();
                    } else {
                        PSAssignee = psAssign2.trim();
                    }
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    autoSolvedL3[i].CName = CustomerName;
                    autoSolvedL3[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.trim();
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    autoSolvedL3[i].PSAssignee = PSAssignee;
                    autoSolvedL3[i].PSAssignee2 = PSAssignee2;
                    autoSolvedL3[i].Severity = severity;
                    var createdTime = autoSolvedL3[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = autoSolvedL3[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    autoSolvedL3[i].days = days;
                }
                arrToSetSegData[0].push(autoSolvedL3);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
    }
    if (arrToSetSegData[0][1].length !== 0) {
        flxRowTemp.forceLayout();
        frmDashboard.flxIndicators.opacity = 0.1;
        if (flxId === "flxAC0" || flxId === "flxAC1") {
            frmDashboard.flxPopupLead.setVisibility(true);
            frmDashboard.flxPopupLead.forceLayout();
        }
    } else {
        frmDashboard.flxIndicators.opacity = 1;
        alert("Sorry there are no tickets to display");
        frmDashboard.flxIndicators.opacity = 1;
    }
}