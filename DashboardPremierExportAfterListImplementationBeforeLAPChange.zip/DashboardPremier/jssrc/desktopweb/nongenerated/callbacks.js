//Type your code here
function prepareData(ticketsArr, type, callback) {
    for (n = 0; n < ticketsArr.length; n++) {
        if (ticketsArr[n].AssigneeId === 14272801548) {
            assigneeKind = "BDE";
        } else {
            assigneeKind = "CSE";
        }
        var customArr = ticketsArr[n].CustomField;
        for (var k = 0; k < customArr.length; k++) {
            if (customArr[k].id === 21145230) {
                psAssign = customArr[k].value;
            } else if (customArr[k].id === 114094136854) {
                psAssign2 = customArr[k].value;
            } else if (customArr[k].id === 22618834) {
                ETA = customArr[k].value;
            }
        }
        if (type == "cse") {
            if (assigneeKind === "BDE") {
                PSAssignee = psAssign2.trim();
                PSAssignee2 = "Kony BDE Product Support";
            } else {
                PSAssignee = psAssign.trim();
                PSAssignee2 = "Kony Product Support";
            }
            ticketsArr[n].PSAssignee2 = PSAssignee2;
        } else if (type == "product" || type == "cloud") {
            if (ETA !== null && ETA !== "") {
                ticketsArr[n].PSAssignee2 = ETA.toString();
            } else {
                ticketsArr[n].PSAssignee2 = "-";
            }
            if (psAssign2 === "") {
                PSAssignee = psAssign.trim();
            } else {
                PSAssignee = psAssign2.trim();
            }
        }
        PSAssignee = PSAssignee.trim();
        PSAssignee = PSAssignee.replace("_", " ");
        PSAssignee = PSAssignee.replace("_", " ");
        PSAssignee = PSAssignee.replace("_", " ");
        PSAssignee = PSAssignee.replace("-", " ");
        var arr = PSAssignee.split(' ');
        var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
        if (arr.length > 1) {
            var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
            if (second !== "Tickets" || second !== "Bde") {
                PSAssignee = first + " " + second;
            } else {
                PSAssignee = first;
            }
        } else {
            PSAssignee = first;
        }
        if (PSAssignee === "") {
            PSAssignee = "None";
        }
        createdTime = ticketsArr[n].CreatedAt;
        currentTime = new Date();
        updatedTime = ticketsArr[n].UpdatedAt;
        localDate = new Date(createdTime);
        date = new Date();
        hours = Math.abs(date - localDate) / 36e5;
        days = hours / 24;
        days = Math.round(days * 10) / 10;
        ticketsArr[n].days = days;
        valId = ticketsArr[n].ticketId;
        ticketsArr[n].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
        ticketsArr[n].PSAssignee = PSAssignee;
        ticketsArr[n].Severity = ticketsArr[n].severityOfTicket;
    }
    arrToSetSegData[0].push(ticketsArr);
    frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
    callback();
}

function callback() {
    if (arrToSetSegData[0][1].length !== 0) {
        frmDashboard.flxIndicators.opacity = 0.1;
        frmDashboard.flxIndicators.forceLayout();
        flxRowTemp.forceLayout();
        frmDashboard.flxPopupLag.setVisibility(true);
        frmDashboard.flxPopupLag.forceLayout();
    } else {
        frmDashboard.flxIndicators.opacity = 1;
        alert("Sorry there are no tickets to display");
    }
}