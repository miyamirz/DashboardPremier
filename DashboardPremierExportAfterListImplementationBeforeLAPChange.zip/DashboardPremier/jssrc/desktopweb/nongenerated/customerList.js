//Type your code here
var selectedCustomer = "All";

function getCustList() {
    mobileFabricConfiguration.integrationObj1 = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[2].service);
    var operationName = mobileFabricConfiguration.integrationServices[2].operations[0];
    headers = {};
    data = {};
    mobileFabricConfiguration.integrationObj1.invokeOperation(operationName, headers, data, listSuccess, listError);
}

function listSuccess(listResponse) {
    //console.log(frmDashboard.flxHeader.flxList.custList.masterData);
    // frmDashboard.flxHeader.flxList.custList.masterData=[["cust","customer"],["cust2","cust2"]];
    //   frmDashboard.flxHeader.flxList.custList.masterDataMap=[
    // 	[
    // 		{"mykey":"key1","myvalue":"value1"}, 
    // 		{"mykey":"key2","myvalue":"value2"}, 
    // 		{"mykey":"key3","myvalue":"value3"}
    // 	], "mykey","myvalue"
    // ];
    var listArray = [
        ["All", "All"]
    ];
    for (var z = 0; z < listResponse.customerList.length; z++) {
        var temp = [];
        var config = {};
        config = {
            "custType": listResponse.customerList[z].custType
        };
        var val = listResponse.customerList[z].custName;
        val = val.trim();
        val = val.toString();
        var key = listResponse.customerList[z].custMap;
        key = key.trim();
        key = key.toString();
        temp.push(key);
        temp.push(val);
        temp.push(config);
        listArray.push(temp);
    }
    frmDashboard.flxHeader.flxList.custList.masterData = listArray;
    console.log("Array of customer List" + listArray);
}

function listError() {
    alert("Errror in retreiving customer list");
}

function onListSelection(list) {
    hidePopups();
    var element = document.getElementById("canvas");
    element.innerHTML = "";
    selectedCustomer = list.selectedkeyvalue[0];
    if (selectedCustomer === "All") {
        window.location.reload();
    } else {
        frmDashboard.flxIndicators.opacity = 0.1;
        kony.application.showLoadingScreen("loadSkin", "", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, false, true, {
            enableMenuKey: true,
            enableBackKey: true,
            shouldShowLabelInBottom: "true",
            progressIndicatorColor: "ffffff77"
        });
        if (list.selectedkeyvalue[2].custType === "Mission Critical") {
            frmDashboard.flxHeader.lblAppName.text = "Mission Critical Dashboard";
        } else {
            frmDashboard.flxHeader.lblAppName.text = "Premier Dashboard";
        }
        initializeSolvedMTTRSpeedometer();
        toSetCLDataForCountBasedResponse(selectedCustomer);
        clLeadTab();
    }
}

function initializeSolvedMTTRSpeedometer() {
    cseSolvedMTTR = [];
    productSolvedMTTR = [];
    cloudSolvedMTTR = [];
    cseCurrentMonthTickets = [];
    cloudCurrentMonthTickets = [];
    productCurrentMonthTickets = [];
    cseSolvedMTTRVal = 0;
    productSolvedMTTRVal = 0;
    cloudSolvedMTTRVal = 0;
    overAllSolvedMTTRVal = 0;
}

function hidePopups() {
    frmDashboard.flxPopupLead.setVisibility(false);
    frmDashboard.flxPopupLag.setVisibility(false);
}