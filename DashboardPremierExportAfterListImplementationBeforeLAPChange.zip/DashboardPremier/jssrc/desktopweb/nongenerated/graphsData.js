//Type your code here
var ticketsForGraphs = [];
var day;

function getGraphData() {
    var openGraphTickets = [];
    var solvedGraphTickets = [];
    var garbageTickets = [];
    if (openCse.ticketsCount !== "0") ticketsForGraphs.push(openCse.tickets);
    else ticketsForGraphs.push([]);
    if (openProduct.ticketsCount !== "0") ticketsForGraphs.push(openProduct.tickets);
    else ticketsForGraphs.push([]);
    if (openCloud.ticketsCount !== "0") ticketsForGraphs.push(openCloud.tickets);
    else ticketsForGraphs.push([]);
    if (pendingCse.ticketsCount !== "0") ticketsForGraphs.push(pendingCse.tickets);
    else ticketsForGraphs.push([]);
    if (pendingProduct.ticketsCount !== "0") ticketsForGraphs.push(pendingProduct.tickets);
    else ticketsForGraphs.push([]);
    if (pendingCloud.ticketsCount !== "0") ticketsForGraphs.push(pendingCloud.tickets);
    else ticketsForGraphs.push([]);
    if (solvedCse.ticketsCount !== "0") ticketsForGraphs.push(solvedCse.tickets);
    else ticketsForGraphs.push([]);
    if (solvedProduct.ticketsCount !== "0") ticketsForGraphs.push(solvedProduct.tickets);
    else ticketsForGraphs.push([]);
    if (solvedCloud.ticketsCount !== "0") ticketsForGraphs.push(solvedCloud.tickets);
    else ticketsForGraphs.push([]);
    var date = new Date();
    day = date.getDay();
    switch (day) {
        case 0:
            day = "Sun";
            break;
        case 1:
            day = "Mon";
            break;
        case 2:
            day = "Tue";
            break;
        case 3:
            day = "Wed";
            break;
        case 4:
            day = "Thur";
            break;
        case 5:
            day = "Fri";
            break;
        case 6:
            day = "Sat";
            break;
    }
    var newDate = "" + date.getDate() + "/" + (date.getMonth() + 1) + "/" + (date.getYear() + 1900);
    for (var i = 0; i < ticketsForGraphs.length; i++) {
        for (var j = 0; j < ticketsForGraphs[i].length; j++) {
            var createdTime = ticketsForGraphs[i][j].CreatedAt;
            var localDate = new Date(createdTime);
            var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
            if (newDate === CDate) {
                if (ticketsForGraphs[i][j].Status === "open" || ticketsForGraphs[i][j].Status === "pending") {
                    openGraphTickets.push(ticketsForGraphs[i][j]);
                } else if (ticketsForGraphs[i][j].Status === "solved") {
                    solvedGraphTickets.push(ticketsForGraphs[i][j]);
                } else {
                    garbageTickets.push(ticketsForGraphs[i][j]);
                }
            }
        }
    }
    openLength = openGraphTickets.length;
    solvedLength = solvedGraphTickets.length;
    garbageLength = garbageTickets.length;
    var temp = {};
    temp.openPendingGraphTickets = openGraphTickets;
    temp.solvedGraphTickets = solvedGraphTickets;
    ticketsObjectForGraphs = temp;
    mobileFabricConfiguration.integrationObj1 = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[1].service);
    var operationName = mobileFabricConfiguration.integrationServices[1].operations[0];
    headers = {};
    data = {
        "day": day,
        "OpenPendingVal": openLength,
        "SolvedVal": solvedLength,
        "GraphTickets": ticketsObjectForGraphs
    };
    if (selectedCustomer === "All") mobileFabricConfiguration.integrationObj1.invokeOperation(operationName, headers, data, getDataSuccessCallback, getDataErrorCallback);
    else getDataSuccessCallback(selectedCustomer);
}

function getDataSuccessCallback(res) {
    mobileFabricConfiguration.integrationObj1 = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[1].service);
    var operationName = mobileFabricConfiguration.integrationServices[1].operations[1];
    headers = {};
    data = {};
    mobileFabricConfiguration.integrationObj1.invokeOperation(operationName, headers, data, readSuccessCallback, readErrorCallback);
}

function getDataErrorCallback(res) {
    //alert("Error in updataing data for Line Chart");
    frmDashboard.flxIndicators.opacity = 1;
}

function readSuccessCallback(res) {
    var OPCount = 0;
    var SCount = 0;
    for (var k = 0; k < res.graphinputs.length; k++) {
        if (selectedCustomer !== "All") {
            if (res.graphinputs[k].GraphTickets) {
                var resInString = res.graphinputs[k].GraphTickets;
                var resInObject = JSON.parse(resInString);
                for (var z = 0; z < resInObject.openPendingGraphTickets.length; z++) {
                    if (!resInObject.openPendingGraphTickets[z].CName) {
                        var customArr = resInObject.openPendingGraphTickets[z].CustomField;
                        for (var m = 0; m < customArr.length; m++) {
                            if (customArr[k].id === 21277110) {
                                custName = customArr[k].value;
                            } else if (customArr[k].id === 21062879) {
                                custAcc = customArr[k].value;
                            }
                        }
                        if (custName !== null) CustomerName = custName.trim();
                        else CustomerName = "none";
                        if (custAcc !== null) CustomerAccountName = custAcc.trim();
                        else CustomerAccountName = "none";
                        resInObject.openPendingGraphTickets[z].CName = CustomerName;
                        resInObject.openPendingGraphTickets[z].CAccountName = CustomerAccountName;
                    }
                    if (resInObject.openPendingGraphTickets[z].CName === selectedCustomer || resInObject.openPendingGraphTickets[z].CAccountName === selectedCustomer) {
                        OPCount++;
                    }
                }
                for (var l = 0; l < resInObject.solvedGraphTickets.length; l++) {
                    if (!resInObject.solvedGraphTickets[l].CName) {
                        var customArr = resInObject.solvedGraphTickets[l].CustomField;
                        for (var m = 0; m < customArr.length; m++) {
                            if (customArr[k].id === 21277110) {
                                custName = customArr[k].value;
                            } else if (customArr[k].id === 21062879) {
                                custAcc = customArr[k].value;
                            }
                        }
                        if (custName !== null) CustomerName = custName.trim();
                        else CustomerName = "none";
                        if (custAcc !== null) CustomerAccountName = custAcc.trim();
                        else CustomerAccountName = "none";
                        resInObject.solvedGraphTickets[l].CName = CustomerName;
                        resInObject.solvedGraphTickets[l].CAccountName = CustomerAccountName;
                    }
                    if (resInObject.solvedGraphTickets[l].CName === selectedCustomer || resInObject.solvedGraphTickets[l].CAccountName === selectedCustomer) {
                        SCount++;
                    }
                }
                res.graphinputs[k].OpenPendingVal = OPCount.toString();
                res.graphinputs[k].SolvedVal = SCount.toString();
                OPCount = 0;
                SCount = 0;
            }
        }
        if (res.graphinputs[k].day === "Mon") {
            MonOpen = res.graphinputs[k].OpenPendingVal;
            MonSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Tue") {
            TueOpen = res.graphinputs[k].OpenPendingVal;
            TueSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Wed") {
            WedOpen = res.graphinputs[k].OpenPendingVal;
            WedSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Thur") {
            ThurOpen = res.graphinputs[k].OpenPendingVal;
            ThurSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Fri") {
            FriOpen = res.graphinputs[k].OpenPendingVal;
            FriSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Sat") {
            SatOpen = res.graphinputs[k].OpenPendingVal;
            SatSolved = res.graphinputs[k].SolvedVal;
        } else if (res.graphinputs[k].day === "Sun") {
            SunOpen = res.graphinputs[k].OpenPendingVal;
            SunSolved = res.graphinputs[k].SolvedVal;
        }
    }
    switch (day) {
        case "Mon":
            temp = {
                "labels": ["Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday"],
                "data1": [TueOpen, WedOpen, ThurOpen, FriOpen, SatOpen, SunOpen, MonOpen],
                "data2": [TueSolved, WedSolved, ThurSolved, FriSolved, SatSolved, SunSolved, MonSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Tue":
            temp = {
                "labels": ["Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday"],
                "data1": [WedOpen, ThurOpen, FriOpen, SatOpen, SunOpen, MonOpen, TueOpen],
                "data2": [WedSolved, ThurSolved, FriSolved, SatSolved, SunSolved, MonSolved, TueSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Wed":
            temp = {
                "labels": ["Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"],
                "data1": [ThurOpen, FriOpen, SatOpen, SunOpen, MonOpen, TueOpen, WedOpen],
                "data2": [ThurSolved, FriSolved, SatSolved, SunSolved, MonSolved, TueSolved, WedSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Thur":
            temp = {
                "labels": ["Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
                "data1": [FriOpen, SatOpen, SunOpen, MonOpen, TueOpen, WedOpen, ThurOpen],
                "data2": [FriSolved, SatSolved, SunSolved, MonSolved, TueSolved, WedSolved, ThurSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Fri":
            temp = {
                "labels": ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "data1": [SatOpen, SunOpen, MonOpen, TueOpen, WedOpen, ThurOpen, FriOpen],
                "data2": [SatSolved, SunSolved, MonSolved, TueSolved, WedSolved, ThurSolved, FriSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Sat":
            temp = {
                "labels": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "data1": [SunOpen, MonOpen, TueOpen, WedOpen, ThurOpen, FriOpen, SatOpen],
                "data2": [SunSolved, MonSolved, TueSolved, WedSolved, ThurSolved, FriSolved, SatSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
        case "Sun":
            temp = {
                "labels": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                "data1": [MonOpen, TueOpen, WedOpen, ThurOpen, FriOpen, SatOpen, SunOpen],
                "data2": [MonSolved, TueSolved, WedSolved, ThurSolved, FriSolved, SatSolved, SunSolved]
            };
            frmDashboard.lineChart.chartData = temp;
            break;
    }
}

function readErrorCallback(res) {
    //alert("Error in reading chart data");
    frmDashboard.flxIndicators.opacity = 1;
}