//Type your code here
//Type your code here
//Type your code here
function showNFRPopup(context) {
    var flxId = context.constructorList[0].id;
    var i;
    frmDashboard.flxPopupLead.segPopupLead.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        slblDynamic: "slblDynamic",
        slblStatus: "slblStatus",
        lblTicket: "valId",
        lblSeverity: "Severity",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee",
        lblDynamic: "PSAssignee2",
        lblStatus: "Status",
    };
    arrToSetSegData = [
        [{
            slblTicket: "Ticket Id",
            slblSupportPlan: "Support Plan",
            slblSeverity: "Severity",
            slblCustName: "Customer Name",
            slblCreated: "Age(Days)",
            slblUpdated: "UpdatedAt",
            slblPsAssignee: "CSE Assignee",
            slblStatus: "Status"
        }, ]
    ];
    switch (flxId) {
        case "flxNR0":
            if (nfrCse.ticketsCount !== "0") {
                arrToSetSegData[0][0].slblDynamic = "Assignee";
                for (i = 0; i < nfrCse.tickets.length; i++) {
                    if (openCse.tickets[i].AssigneeId === 14272801548) {
                        assigneeKind = "BDE";
                    } else {
                        assigneeKind = "CSE";
                    }
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = nfrCse.tickets[i].ticketId;
                    nfrCse.tickets[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = nfrCse.tickets[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                    }
                    if (ETA !== null && ETA !== "") {
                        nfrCse.tickets[i].ETA = ETA.toString();
                    } else {
                        nfrCse.tickets[i].ETA = "";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (assigneeKind === "BDE") {
                        PSAssignee = psAssign2.trim();
                        PSAssignee2 = "Kony BDE Product Support";
                    } else {
                        PSAssignee = psAssign.trim();
                        PSAssignee2 = "Kony Product Support";
                    }
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    nfrCse.tickets[i].CName = CustomerName;
                    nfrCse.tickets[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.trim();
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets" || second !== "Bde") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    nfrCse.tickets[i].PSAssignee = PSAssignee;
                    nfrCse.tickets[i].PSAssignee2 = PSAssignee2;
                    nfrCse.tickets[i].Severity = severity;
                    var createdTime = nfrCse.tickets[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = nfrCse.tickets[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    days = days.toString();
                    nfrCse.tickets[i].days = days;
                    //  nfrCse.tickets[i].CreatedAt=createdDateTime;
                    //  nfrCse.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(nfrCse.tickets);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
        case "flxNR1":
            if (nfrProduct.ticketsCount !== "0") {
                arrToSetSegData[0][0].slblDynamic = "ETA";
                for (i = 0; i < nfrProduct.tickets.length; i++) {
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = nfrProduct.tickets[i].ticketId;
                    nfrProduct.tickets[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = nfrProduct.tickets[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                        //  kony.print("iteration count in inner for loop:"+k);
                    }
                    if (ETA !== null && ETA !== "") {
                        nfrProduct.tickets[i].PSAssignee2 = ETA.toString();
                    } else {
                        nfrProduct.tickets[i].PSAssignee2 = "-";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (psAssign2 === "") {
                        PSAssignee = psAssign.trim();
                    } else {
                        PSAssignee = psAssign2.trim();
                    }
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    nfrProduct.tickets[i].CName = CustomerName;
                    nfrProduct.tickets[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.trim();
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets" || second !== "Bde") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    nfrProduct.tickets[i].PSAssignee = PSAssignee;
                    nfrProduct.tickets[i].PSAssignee2 = PSAssignee2;
                    nfrProduct.tickets[i].Severity = severity;
                    var createdTime = nfrProduct.tickets[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = nfrProduct.tickets[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    days = days.toString();
                    nfrProduct.tickets[i].days = days;
                    //   nfrProduct.tickets[i].CreatedAt=createdDateTime;
                    // nfrProduct.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(nfrProduct.tickets);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
    }
    if (arrToSetSegData[0][1].length !== 0) {
        flxRowTemp.forceLayout();
        frmDashboard.flxIndicators.opacity = 0.1;
        if (flxId === "flxNR0" || flxId === "flxNR1") {
            frmDashboard.flxPopupLead.setVisibility(true);
            frmDashboard.flxPopupLead.forceLayout();
        }
    } else {
        frmDashboard.flxIndicators.opacity = 1;
        alert("Sorry there are no tickets to display");
    }
} //Type your code here//Type your code here