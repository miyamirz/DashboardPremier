//Type your code here
//Type your code here
var rcCseTickets = [];
var rcProductTickets = [];
var rcCloudTickets = [];
var solCseTickets = [];
var solProductTickets = [];
var solCloudTickets = [];

function showRC_SOLPopup(context) {
    var flxId = context.constructorList[0].id;
    var m, n;
    if (selectedCustomer === "All") {
        rcArrCse = rootCausePopupCse;
        rcArrProduct = rootCausePopupProduct;
        rcArrCloud = rootCausePopupCloud;
        solArrCse = solutionPopupCse;
        solArrProduct = solutionPopupProduct;
        solArrCloud = solutionPopupCloud;
    } else {
        rcArrCse = clRCPopupCse;
        rcArrProduct = clRCPopupProduct;
        rcArrCloud = clRCPopupCloud;
        solArrCse = clSolPopupCse;
        solArrProduct = clSolPopupProduct;
        solArrCloud = clSolPopupCloud;
    }
    if (flxId === "flxRCCse") {
        for (m = 0; m < rcArrCse.length; m++) {
            for (n = 0; n < monthTicketsSolvedCse.length; n++) {
                if (rcArrCse[m] === monthTicketsSolvedCse[n].ticketId) {
                    rcCseTickets.push(monthTicketsSolvedCse[n]);
                    break;
                }
            }
        }
    } else if (flxId === "flxRCProduct") {
        for (m = 0; m < rcArrProduct.length; m++) {
            for (n = 0; n < monthTicketsSolvedProduct.length; n++) {
                if (rcArrProduct[m] === monthTicketsSolvedProduct[n].ticketId) {
                    rcProductTickets.push(monthTicketsSolvedProduct[n]);
                    break;
                }
            }
        }
    } else if (flxId === "flxRCCloud") {
        for (m = 0; m < rcArrCloud.length; m++) {
            for (n = 0; n < monthTicketsSolvedCloud.length; n++) {
                if (rcArrCloud[m] === monthTicketsSolvedCloud[n].ticketId) {
                    rcCloudTickets.push(monthTicketsSolvedCloud[n]);
                    break;
                }
            }
        }
    } else if (flxId === "flxSolCse") {
        for (m = 0; m < solArrCse.length; m++) {
            for (n = 0; n < monthTicketsSolvedCse.length; n++) {
                if (solArrCse[m] === monthTicketsSolvedCse[n].ticketId) {
                    solCseTickets.push(monthTicketsSolvedCse[n]);
                    break;
                }
            }
        }
    } else if (flxId === "flxSolProduct") {
        for (m = 0; m < solArrProduct.length; m++) {
            for (n = 0; n < monthTicketsSolvedProduct.length; n++) {
                if (solArrProduct[m] === monthTicketsSolvedProduct[n].ticketId) {
                    solProductTickets.push(monthTicketsSolvedProduct[n]);
                    break;
                }
            }
        }
    } else if (flxId === "flxSolCloud") {
        for (m = 0; m < solArrCloud.length; m++) {
            for (n = 0; n < monthTicketsSolvedCloud.length; n++) {
                if (solArrCloud[m] === monthTicketsSolvedCloud[n].ticketId) {
                    solCloudTickets.push(monthTicketsSolvedCloud[n]);
                    break;
                }
            }
        }
    }
    frmDashboard.flxPopupLag.segPopupLag.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        slblDynamic: "slblDynamic",
        slblStatus: "slblStatus",
        lblTicket: "valId",
        lblSeverity: "Severity",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee",
        lblDynamic: "PSAssignee2",
        lblStatus: "Status"
    };
    arrToSetSegData = [
        [{
            slblTicket: "Ticket Id",
            slblSupportPlan: "Support Plan",
            slblSeverity: "Severity",
            slblCustName: "Customer Name",
            slblCreated: "Age(Days)",
            slblUpdated: "UpdatedAt",
            slblPsAssignee: "CSE Assignee",
            slblStatus: "Status",
        }, ]
    ];
    switch (flxId) {
        case "flxRCCse":
            arrToSetSegData[0][0].slblDynamic = "Assignee";
            prepareData(rcCseTickets, "cse", callback);
            //                      	for(n=0;n<rcCseTickets.length;n++)
            //                        {
            //                                     createdTime=rcCseTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=rcCseTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          rcCseTickets[n].days=days;
            //                          valId=rcCseTickets[n].ticketId;
            //                          rcCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(rcCseTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            rcCseTickets = [];
            break;
        case "flxRCProduct":
            arrToSetSegData[0][0].slblDynamic = "ETA";
            prepareData(rcProductTickets, "product", callback);
            //                      	for(n=0;n<rcProductTickets.length;n++)
            //                        {
            //                           createdTime=rcProductTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=rcProductTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          rcProductTickets[n].days=days;
            //                          valId=rcProductTickets[n].ticketId;
            //                          rcProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(rcProductTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            rcProductTickets = [];
            break;
        case "flxRCCloud":
            arrToSetSegData[0][0].slblDynamic = "ETA";
            prepareData(rcCloudTickets, "cloud", callback);
            //                      	for(n=0;n<rcCloudTickets.length;n++)
            //                        {
            //                           createdTime=rcCloudTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=rcCloudTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          rcCloudTickets[n].days=days;
            //                          valId=rcCloudTickets[n].ticketId;
            //                          rcCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(rcCloudTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            rcCloudTickets = [];
            break;
        case "flxSolCse":
            arrToSetSegData[0][0].slblDynamic = "Assignee";
            prepareData(solCseTickets, "cse", callback);
            //                      	for(n=0;n<solCseTickets.length;n++)
            //                        {
            //                           createdTime=solCseTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=solCseTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          solCseTickets[n].days=days;
            //                          valId=solCseTickets[n].ticketId;
            //                          solCseTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(solCseTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            solCseTickets = [];
            break;
        case "flxSolProduct":
            arrToSetSegData[0][0].slblDynamic = "ETA";
            prepareData(solProductTickets, "product", callback);
            //                      	for(n=0;n<solProductTickets.length;n++)
            //                        {
            //                           createdTime=solProductTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=solProductTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          solProductTickets[n].days=days;
            //                          valId=solProductTickets[n].ticketId;
            //                          solProductTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(solProductTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            solProductTickets = [];
            break;
        case "flxSolCloud":
            arrToSetSegData[0][0].slblDynamic = "ETA";
            prepareData(solCloudTickets, "cloud", callback);
            //                      	for(n=0;n<solCloudTickets.length;n++)
            //                        {
            //                           createdTime=solCloudTickets[n].CreatedAt;
            //     							 currentTime=new Date();
            //    							  updatedTime=solCloudTickets[n].UpdatedAt;
            //                           localDate = new Date(createdTime);
            // 						date= new Date();
            // 								 hours = Math.abs(date - localDate) / 36e5;
            //                           days=hours/24;
            // 							 days = Math.round( days * 10 ) / 10;
            //                          solCloudTickets[n].days=days;
            //                          valId=solCloudTickets[n].ticketId;
            //                          solCloudTickets[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
            //                        }
            //                      arrToSetSegData[0].push(solCloudTickets);
            //       			   frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
            solCloudTickets = [];
            break;
    }
    //   if(arrToSetSegData[0][1].length!==0)
    //    {
    //    frmDashboard.flxIndicators.opacity=0.1;     
    //      frmDashboard.flxIndicators.forceLayout();
    //   flxRowTemp.forceLayout();
    //    frmDashboard.flxPopupLag.setVisibility(true);
    //    frmDashboard.flxPopupLag.forceLayout();
    //    }
    //   else
    //     {
    //      frmDashboard.flxIndicators.opacity=1;
    //       alert("Sorry there are no tickets to display");
    //     }
}