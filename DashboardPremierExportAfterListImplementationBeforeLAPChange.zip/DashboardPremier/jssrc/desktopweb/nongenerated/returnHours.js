//Type your code here
function returnHours(ticket) {
    var createdTime = ticket.CreatedAt;
    var localDate = new Date(createdTime);
    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
    var lDateString = localDate.toString();
    var CTime = lDateString.substr(16, 8);
    var createdDateTime = CDate + " " + CTime;
    var date = new Date();
    var hours = Math.abs(date - localDate) / 36e5;
    return hours;
}