popupTicketsArr = [];
mttrTicketsArr = [];
criticalHours = 0;
highHours = 0;
mediumHours = 0;
lowHours = 0;
firstResponseBreachedArr = [];
var mttrCseTickets = [];
var mttrProductTickets = [];
var mttrCloudTickets = [];
popupTicketsBreachedArr = [];

function criticalTicketsToBreach(arr1, viewCheck) {
    // kony.print("arr1 length :"+arr1.length);
    //   kony.print("arr:"+JSON.Stringify(arr1));
    var a, b;
    if (viewCheck === 2) {
        a = 12;
        b = 24;
    } else if (viewCheck === 3) {
        a = 21;
        b = 24;
    } else if (viewCheck === 4) {
        a = 2;
        b = 4;
    }
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr1.length; k++) {
        var customArr = arr1[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr1[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr1[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            criticalHours += hours;
            if (hours > a && hours <= b) {
                arr1[k].hours = hours;
                arr1[k].CreatedAt = createdTime;
                arr1[k].UpdatedAt = updatedDateTime;
                delete arr1[k].CreatedNew;
                delete arr1[k].UpdatedNew;
                //delete arr1[k].CustomField;
                tempArr.push(arr1[k]);
                popupTicketsArr.push(arr1[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            criticalHours += hours;
            if (hours > a && hours <= b) {
                arr1[k].hours = hours;
                arr1[k].CreatedAt = createdTime;
                arr1[k].UpdatedAt = updatedDateTime;
                delete arr1[k].CreatedNew;
                delete arr1[k].UpdatedNew;
                //delete arr1[k].CustomField;
                tempArr.push(arr1[k]);
                popupTicketsArr.push(arr1[k]);
            }
        }
    }
    return tempArr;
}

function criticalTicketsBreached(arr2, viewCheck) {
    //kony.print("arr2 length :"+arr2.length);
    //   kony.print("arr:"+JSON.Stringify(arr2));
    var a;
    if (viewCheck === 2) {
        a = 24;
    } else if (viewCheck === 3) {
        a = 24;
    } else if (viewCheck === 4) {
        a = 4;
    }
    tempArr = [];
    for (var k = 0; k < arr2.length; k++) {
        var customArr = arr2[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr2[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr2[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            if (hours > a && hours > 192) {
                arr2[k].hours = hours;
                arr2[k].CreatedAt = createdTime;
                arr2[k].UpdatedAt = updatedDateTime;
                delete arr2[k].CreatedNew;
                delete arr2[k].UpdatedNew;
                //delete arr2[k].CustomField;
                //tempArr1.push(arr2[k]);
                mttrTicketsArr.push(arr2[k]);
                tempArr.push(arr2[k]);
                popupTicketsBreachedArr.push(arr2[k]);
            } else if (hours > a) {
                arr2[k].hours = hours;
                arr2[k].CreatedAt = createdTime;
                arr2[k].UpdatedAt = updatedDateTime;
                delete arr2[k].CreatedNew;
                delete arr2[k].UpdatedNew;
                // delete arr2[k].CustomField;
                tempArr.push(arr2[k]);
                popupTicketsBreachedArr.push(arr2[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            if (hours > a && hours > 192) {
                arr2[k].hours = hours;
                arr2[k].CreatedAt = createdTime;
                arr2[k].UpdatedAt = updatedDateTime;
                delete arr2[k].CreatedNew;
                delete arr2[k].UpdatedNew;
                //delete arr2[k].CustomField;
                //tempArr1.push(arr2[k]);
                mttrTicketsArr.push(arr2[k]);
                tempArr.push(arr2[k]);
                popupTicketsBreachedArr.push(arr2[k]);
            } else if (hours > a) {
                arr2[k].hours = hours;
                arr2[k].CreatedAt = createdTime;
                arr2[k].UpdatedAt = updatedDateTime;
                delete arr2[k].CreatedNew;
                delete arr2[k].UpdatedNew;
                // delete arr2[k].CustomField;
                tempArr.push(arr2[k]);
                popupTicketsBreachedArr.push(arr2[k]);
            }
        }
    }
    return tempArr;
}

function criticalTicketsBreached1(arr3) {
    //kony.print("arr3 length :"+arr3.length);
    //   kony.print("arr:"+JSON.Stringify(arr3));
    tempArr = [];
    for (var k = 0; k < arr3.length; k++) {
        var customArr = arr3[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr3[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr3[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr3[k].CreatedAt = localDate;
        arr3[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 0.5) {
            if (selectedCustomer === "All") {
                arr3[k].hours = hours;
                arr3[k].CreatedAt = createdTime;
                tempArr.push(arr3[k]);
                firstResponseBreachedArr.push(tempArr);
            } else {
                if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
                    arr3[k].hours = hours;
                    arr3[k].CreatedAt = createdTime;
                    tempArr.push(arr3[k]);
                    firstResponseBreachedArr.push(tempArr);
                }
            }
        }
    }
    return tempArr;
}

function highTicketsToBreach(arr4, viewCheck) {
    // kony.print("arr4 length :"+arr4.length);
    // kony.print("arr:"+arr4);
    var a, b;
    if (viewCheck === 2) {
        a = 48;
        b = 72;
    } else if (viewCheck === 3) {
        a = 144;
        b = 168;
    } else if (viewCheck === 4) {
        a = 4;
        b = 8;
    }
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr4.length; k++) {
        var customArr = arr4[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr4[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr4[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            highHours += hours;
            if (hours > a && hours <= b) {
                arr4[k].hours = hours;
                arr4[k].CreatedAt = createdTime;
                arr4[k].UpdatedAt = updatedDateTime;
                delete arr4[k].CreatedNew;
                delete arr4[k].UpdatedNew;
                //delete arr4[k].CustomField;
                tempArr.push(arr4[k]);
                popupTicketsArr.push(arr4[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            highHours += hours;
            if (hours > a && hours <= b) {
                arr4[k].hours = hours;
                arr4[k].CreatedAt = createdTime;
                arr4[k].UpdatedAt = updatedDateTime;
                delete arr4[k].CreatedNew;
                delete arr4[k].UpdatedNew;
                //delete arr4[k].CustomField;
                tempArr.push(arr4[k]);
                popupTicketsArr.push(arr4[k]);
            }
        }
        //        if(hours>192)
        //          {
        //            arr4[k].hours=hours;
        //            arr4[k].CreatedAt=createdDateTime;
        //            arr4[k].UpdatedAt=updatedDateTime;
        //            delete arr4[k].CreatedNew;
        //            delete arr4[k].UpdatedNew;
        //            delete arr4[k].CustomField;
        //             tempArr1.push(arr4[k]);
        //            mttrTicketsArr.push(arr4[k]);
        //          }
    }
    return tempArr;
}

function highTicketsBreached(arr5, viewCheck) {
    //kony.print("arr5 length :"+arr5.length);
    // kony.print("arr:"+arr5);
    var a;
    if (viewCheck === 2) {
        a = 72;
    } else if (viewCheck === 3) {
        a = 168;
    } else if (viewCheck === 4) {
        a = 8;
    }
    tempArr = [];
    for (var k = 0; k < arr5.length; k++) {
        var customArr = arr5[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr5[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr5[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            if (hours > a && hours > 192) {
                arr5[k].hours = hours;
                arr5[k].CreatedAt = createdTime;
                arr5[k].UpdatedAt = updatedDateTime;
                delete arr5[k].CreatedNew;
                delete arr5[k].UpdatedNew;
                //delete arr5[k].CustomField;
                mttrTicketsArr.push(arr5[k]);
                tempArr.push(arr5[k]);
                popupTicketsBreachedArr.push(arr5[k]);
            } else if (hours > a) {
                arr5[k].hours = hours;
                arr5[k].CreatedAt = createdTime;
                arr5[k].UpdatedAt = updatedDateTime;
                delete arr5[k].CreatedNew;
                delete arr5[k].UpdatedNew;
                //  delete arr5[k].CustomField;
                tempArr.push(arr5[k]);
                popupTicketsBreachedArr.push(arr5[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            if (hours > a && hours > 192) {
                arr5[k].hours = hours;
                arr5[k].CreatedAt = createdTime;
                arr5[k].UpdatedAt = updatedDateTime;
                delete arr5[k].CreatedNew;
                delete arr5[k].UpdatedNew;
                //delete arr5[k].CustomField;
                mttrTicketsArr.push(arr5[k]);
                tempArr.push(arr5[k]);
                popupTicketsBreachedArr.push(arr5[k]);
            } else if (hours > a) {
                arr5[k].hours = hours;
                arr5[k].CreatedAt = createdTime;
                arr5[k].UpdatedAt = updatedDateTime;
                delete arr5[k].CreatedNew;
                delete arr5[k].UpdatedNew;
                //  delete arr5[k].CustomField;
                tempArr.push(arr5[k]);
                popupTicketsBreachedArr.push(arr5[k]);
            }
        }
    }
    return tempArr;
}

function highTicketsBreached1(arr6) {
    // kony.print("arr6 length :"+arr6.length);
    //  kony.print("arr:"+arr6);
    tempArr = [];
    for (var k = 0; k < arr6.length; k++) {
        var customArr = arr6[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr6[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr6[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr6[k].CreatedAt = localDate;
        arr6[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 2) {
            if (selectedCustomer === "All") {
                arr6[k].hours = hours;
                arr6[k].CreatedAt = createdTime;
                tempArr.push(arr6[k]);
                firstResponseBreachedArr.push(tempArr);
            } else {
                if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
                    arr6[k].hours = hours;
                    arr6[k].CreatedAt = createdTime;
                    tempArr.push(arr6[k]);
                    firstResponseBreachedArr.push(tempArr);
                }
            }
        }
    }
    return tempArr;
}

function mediumTicketsToBreach(arr7, viewCheck) {
    // kony.print("arr7 length :"+arr7.length);
    //kony.print("arr:"+arr7);
    var a, b;
    if (viewCheck === 2) {
        a = 144;
        b = 168;
    } else if (viewCheck === 3) {
        a = 480;
        b = 504;
    } else if (viewCheck === 4) {
        a = 96;
        b = 120;
    }
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr7.length; k++) {
        var customArr = arr7[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr7[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr7[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            mediumHours += hours;
            if (hours > a && hours <= b) {
                arr7[k].hours = hours;
                arr7[k].CreatedAt = createdTime;
                arr7[k].UpdatedAt = updatedDateTime;
                delete arr7[k].CreatedNew;
                delete arr7[k].UpdatedNew;
                //delete arr7[k].CustomField;
                tempArr.push(arr7[k]);
                popupTicketsArr.push(arr7[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            mediumHours += hours;
            if (hours > a && hours <= b) {
                arr7[k].hours = hours;
                arr7[k].CreatedAt = createdTime;
                arr7[k].UpdatedAt = updatedDateTime;
                delete arr7[k].CreatedNew;
                delete arr7[k].UpdatedNew;
                //delete arr7[k].CustomField;
                tempArr.push(arr7[k]);
                popupTicketsArr.push(arr7[k]);
            }
        }
        //        if(hours>192)
        //          {
        //            arr7[k].hours=hours;
        //            arr7[k].CreatedAt=createdDateTime;
        //            arr7[k].UpdatedAt=updatedDateTime;
        //            delete arr7[k].CreatedNew;
        //            delete arr7[k].UpdatedNew;
        //            delete arr7[k].CustomField;
        //             tempArr1.push(arr7[k]);
        //            mttrTicketsArr.push(arr7[k]);
        //          }
    }
    return tempArr;
}

function mediumTicketsBreached(arr8, viewCheck) {
    // kony.print("low tickets breached:");
    //kony.print(arr8);
    //kony.print("arr8 length :"+arr8.length);
    // kony.print("arr:"+arr8);
    var a;
    if (viewCheck === 2) {
        a = 168;
    } else if (viewCheck === 3) {
        a = 504;
    } else if (viewCheck === 4) {
        a = 120;
    }
    tempArr = [];
    for (var k = 0; k < arr8.length; k++) {
        var customArr = arr8[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr8[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr8[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr8[k].CreatedNew = localDate;
        arr8[k].UpdatedNew = updatedNew;
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            if (hours > a) {
                arr8[k].hours = hours;
                arr8[k].CreatedAt = createdTime;
                arr8[k].UpdatedAt = updatedDateTime;
                delete arr8[k].CreatedNew;
                delete arr8[k].UpdatedNew;
                // delete arr8[k].CustomField;
                tempArr.push(arr8[k]);
                mttrTicketsArr.push(arr8[k]);
                popupTicketsBreachedArr.push(arr8[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            if (hours > a) {
                arr8[k].hours = hours;
                arr8[k].CreatedAt = createdTime;
                arr8[k].UpdatedAt = updatedDateTime;
                delete arr8[k].CreatedNew;
                delete arr8[k].UpdatedNew;
                // delete arr8[k].CustomField;
                tempArr.push(arr8[k]);
                mttrTicketsArr.push(arr8[k]);
                popupTicketsBreachedArr.push(arr8[k]);
            }
        }
    }
    return tempArr;
}

function mediumTicketsBreached1(arr9) {
    // kony.print("arr9 length :"+arr9.length);
    //kony.print("arr:"+arr9);
    tempArr = [];
    for (var k = 0; k < arr9.length; k++) {
        var customArr = arr9[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr9[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr9[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr9[k].CreatedAt = localDate;
        arr9[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 8) {
            if (selectedCustomer === "All") {
                arr9[k].hours = hours;
                arr9[k].CreatedAt = createdTime;
                tempArr.push(arr9[k]);
                firstResponseBreachedArr.push(tempArr);
            } else {
                if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
                    arr9[k].hours = hours;
                    arr9[k].CreatedAt = createdTime;
                    tempArr.push(arr9[k]);
                    firstResponseBreachedArr.push(tempArr);
                }
            }
        }
    }
    return tempArr;
}

function lowTicketsToBreach(arr12, viewCheck) {
    //  kony.print("arr12 length :"+arr12.length);
    // kony.print("arr:"+arr12);
    var a, b;
    if (viewCheck === 2) {
        a = 240;
        b = 264;
    } else if (viewCheck === 3) {
        a = 480;
        b = 504;
    } else if (viewCheck === 4) {
        a = 96;
        b = 120;
    }
    tempArr = [];
    tempArr1 = [];
    for (var k = 0; k < arr12.length; k++) {
        var customArr = arr12[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr12[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr12[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            lowHours += hours;
            if (hours > a && hours <= b) {
                arr12[k].hours = hours;
                arr12[k].CreatedAt = createdTime;
                arr12[k].UpdatedAt = updatedDateTime;
                delete arr12[k].CreatedNew;
                delete arr12[k].UpdatedNew;
                //delete arr12[k].CustomField;
                tempArr.push(arr12[k]);
                popupTicketsArr.push(arr12[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            lowHours += hours;
            if (hours > a && hours <= b) {
                arr12[k].hours = hours;
                arr12[k].CreatedAt = createdTime;
                arr12[k].UpdatedAt = updatedDateTime;
                delete arr12[k].CreatedNew;
                delete arr12[k].UpdatedNew;
                //delete arr12[k].CustomField;
                tempArr.push(arr12[k]);
                popupTicketsArr.push(arr12[k]);
            }
        }
        //        if(hours>192)
        //          {
        //            arr12[k].hours=hours;
        //            arr12[k].CreatedAt=createdDateTime;
        //            arr12[k].UpdatedAt=updatedDateTime;
        //            delete arr12[k].CreatedNew;
        //            delete arr12[k].UpdatedNew;
        //            delete arr12[k].CustomField;
        //             tempArr1.push(arr12[k]);
        //            mttrTicketsArr.push(arr12[k]);
        //          }
    }
    return tempArr;
}

function lowTicketsBreached(arr11, viewCheck) {
    //  kony.print("low tickets breached:");
    //kony.print(arr11);
    // kony.print("arr11 length :"+arr11.length);
    // kony.print("arr:"+arr11);
    var a;
    if (viewCheck === 2) {
        a = 264;
    } else if (viewCheck === 3) {
        a = 504;
    } else if (viewCheck === 4) {
        a = 120;
    }
    tempArr = [];
    for (var k = 0; k < arr11.length; k++) {
        var customArr = arr11[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr11[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr11[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr11[k].CreatedNew = localDate;
        arr11[k].UpdatedNew = updatedNew;
        var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
        var lDateString = localDate.toString();
        var CTime = lDateString.substr(16, 8);
        var createdDateTime = CDate + " " + CTime;
        var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
        var uString = updatedNew.toString();
        var UTime = uString.substr(16, 8);
        var updatedDateTime = UDate + " " + UTime;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (selectedCustomer === "All") {
            if (hours > a) {
                arr11[k].hours = hours;
                arr11[k].CreatedAt = createdTime;
                arr11[k].UpdatedAt = updatedDateTime;
                delete arr11[k].CreatedNew;
                delete arr11[k].UpdatedNew;
                //delete arr11[k].CustomField;
                tempArr.push(arr11[k]);
                mttrTicketsArr.push(arr11[k]);
                popupTicketsBreachedArr.push(arr11[k]);
            }
        } else if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
            if (hours > a) {
                arr11[k].hours = hours;
                arr11[k].CreatedAt = createdTime;
                arr11[k].UpdatedAt = updatedDateTime;
                delete arr11[k].CreatedNew;
                delete arr11[k].UpdatedNew;
                //delete arr11[k].CustomField;
                tempArr.push(arr11[k]);
                mttrTicketsArr.push(arr11[k]);
                popupTicketsBreachedArr.push(arr11[k]);
            }
        }
    }
    return tempArr;
}

function lowTicketsBreached1(arr10) {
    // kony.print("arr10 length :"+arr10.length);
    //kony.print("arr:"+arr10);
    tempArr = [];
    for (var k = 0; k < arr10.length; k++) {
        var customArr = arr10[k].CustomField;
        for (var z = 0; z < customArr.length; z++) {
            if (customArr[z].id === 21277110) {
                custName = customArr[z].value;
            } else if (customArr[z].id === 21062879) {
                custAcc = customArr[z].value;
            }
        }
        if (custName !== null) CustomerName = custName.trim();
        else CustomerName = "none";
        if (custAcc !== null) CustomerAccountName = custAcc.trim();
        else CustomerAccountName = "none";
        var createdTime = arr10[k].CreatedAt;
        var currentTime = new Date();
        var updatedTime = arr10[k].UpdatedAt;
        var localDate = new Date(createdTime);
        var updatedNew = new Date(updatedTime);
        arr10[k].CreatedAt = localDate;
        arr10[k].UpdatedAt = updatedNew;
        var date = new Date();
        var hours = Math.abs(date - localDate) / 36e5;
        if (hours > 24) {
            if (selectedCustomer === "All") {
                arr10[k].hours = hours;
                arr10[k].CreatedAt = createdTime;
                tempArr.push(arr10[k]);
                firstResponseBreachedArr.push(tempArr);
            } else {
                if (selectedCustomer === CustomerName || selectedCustomer === CustomerAccountName) {
                    arr10[k].hours = hours;
                    arr10[k].CreatedAt = createdTime;
                    tempArr.push(arr10[k]);
                    firstResponseBreachedArr.push(tempArr);
                }
            }
        }
    }
    return tempArr;
}