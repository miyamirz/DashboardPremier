//Type your code here
//Type your code here
function showSolvedPopup(context) {
    var flxId = context.constructorList[0].id;
    var i;
    frmDashboard.flxPopupLead.segPopupLead.widgetDataMap = {
        slblTicket: "slblTicket",
        slblSeverity: "slblSeverity",
        slblCustName: "slblCustName",
        slblCreated: "slblCreated",
        slblPsAssignee: "slblPsAssignee",
        slblDynamic: "slblDynamic",
        slblStatus: "slblStatus",
        lblTicket: "valId",
        lblSeverity: "Severity",
        lblCustName: "CName",
        lblCreated: "days",
        lblPsAssignee: "PSAssignee",
        lblDynamic: "PSAssignee2",
        lblStatus: "Status",
    };
    arrToSetSegData = [
        [{
            slblTicket: "Ticket Id",
            slblSupportPlan: "Support Plan",
            slblSeverity: "Severity",
            slblCustName: "Customer Name",
            slblCreated: "Age(Days)",
            slblUpdated: "UpdatedAt",
            slblPsAssignee: "CSE Assignee",
            slblStatus: "Status",
        }, ]
    ];
    switch (flxId) {
        case "flxS1":
            if (solvedCse.ticketsCount !== "0") {
                arrToSetSegData[0][0].slblDynamic = "Assignee";
                for (i = 0; i < solvedCse.tickets.length; i++) {
                    solvedCse.tickets[i].ETA = "";
                    if (solvedCse.tickets[i].AssigneeId === 14272801548) {
                        assigneeKind = "BDE";
                    } else {
                        assigneeKind = "CSE";
                    }
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = solvedCse.tickets[i].ticketId;
                    solvedCse.tickets[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = solvedCse.tickets[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        }
                        //  kony.print("iteration count in inner for loop:"+k);
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (assigneeKind === "BDE") {
                        PSAssignee = psAssign2.trim();
                        PSAssignee2 = "Kony BDE Product Support";
                    } else {
                        PSAssignee = psAssign.trim();
                        PSAssignee2 = "Kony Product Support";
                    }
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    solvedCse.tickets[i].CName = CustomerName;
                    solvedCse.tickets[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.trim();
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    solvedCse.tickets[i].PSAssignee = PSAssignee;
                    solvedCse.tickets[i].PSAssignee2 = PSAssignee2;
                    solvedCse.tickets[i].Severity = severity;
                    var createdTime = solvedCse.tickets[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = solvedCse.tickets[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    days = days.toString();
                    solvedCse.tickets[i].days = days;
                    //  solvedCse.tickets[i].CreatedAt=createdDateTime;
                    //  solvedCse.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(solvedCse.tickets);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
        case "flxS2":
            if (solvedProduct.ticketsCount !== "0") {
                arrToSetSegData[0][0].slblDynamic = "ETA";
                for (i = 0; i < solvedProduct.tickets.length; i++) {
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = solvedProduct.tickets[i].ticketId;
                    solvedProduct.tickets[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = solvedProduct.tickets[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                        //  kony.print("iteration count in inner for loop:"+k);
                    }
                    if (ETA !== null && ETA !== "") {
                        solvedProduct.tickets[i].PSAssignee2 = ETA.toString();
                    } else {
                        solvedProduct.tickets[i].PSAssignee2 = "-";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    if (psAssign2 === "") {
                        PSAssignee = psAssign.trim();
                    } else {
                        PSAssignee = psAssign2.trim();
                    }
                    //	PSAssignee2="Kony L3 Product Support";
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    solvedProduct.tickets[i].CName = CustomerName;
                    solvedProduct.tickets[i].SupportPlan = SupportPlan;
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets" || second !== "Bde") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    solvedProduct.tickets[i].PSAssignee = PSAssignee;
                    //solvedProduct.tickets[i].PSAssignee2=PSAssignee2;
                    solvedProduct.tickets[i].Severity = severity;
                    var createdTime = solvedProduct.tickets[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = solvedProduct.tickets[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    days = days.toString();
                    solvedProduct.tickets[i].days = days;
                    // solvedProduct.tickets[i].CreatedAt=createdDateTime;
                    //   solvedProduct.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(solvedProduct.tickets);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
        case "flxS3":
            if (solvedCloud.ticketsCount !== "0") {
                arrToSetSegData[0][0].slblDynamic = "ETA";
                for (i = 0; i < solvedCloud.tickets.length; i++) {
                    custName = "";
                    psAssign = "";
                    supPlan = "";
                    valId = solvedCloud.tickets[i].ticketId;
                    solvedCloud.tickets[i].valId = "<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/" + valId + "'>" + valId + "</a>";
                    var customArr = solvedCloud.tickets[i].CustomField;
                    for (var k = 0; k < customArr.length; k++) {
                        if (customArr[k].id === 77167) {
                            severity = customArr[k].value;
                        } else if (customArr[k].id === 21277110) {
                            custName = customArr[k].value;
                        } else if (customArr[k].id === 40952728) {
                            supPlan = customArr[k].value;
                        } else if (customArr[k].id === 21145230) {
                            psAssign = customArr[k].value;
                        } else if (customArr[k].id === 114094136854) {
                            psAssign2 = customArr[k].value;
                        } else if (customArr[k].id === 22618834) {
                            ETA = customArr[k].value;
                        }
                        //  kony.print("iteration count in inner for loop:"+k);
                    }
                    if (ETA !== null && ETA !== "") {
                        solvedCloud.tickets[i].PSAssignee2 = ETA.toString();
                    } else {
                        solvedCloud.tickets[i].PSAssignee2 = "-";
                    }
                    severity = severity.toLowerCase();
                    severity = severity.trim();
                    if (custName !== null && custName !== "") CustomerName = custName.trim();
                    else CustomerName = "none";
                    SupportPlan = supPlan.trim();
                    PSAssignee = psAssign.trim();
                    if (SupportPlan === "supportplan_1") {
                        SupportPlan = "Premier";
                    } else if (SupportPlan === "supportplan_1_1") {
                        SupportPlan = "Premier Plus";
                    }
                    solvedCloud.tickets[i].CName = CustomerName;
                    solvedCloud.tickets[i].SupportPlan = SupportPlan;
                    if (psAssign2 === "") {
                        PSAssignee = psAssign.trim();
                    } else {
                        PSAssignee = psAssign2.trim();
                    }
                    // PSAssignee2="Kony Cloud ";
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("_", " ");
                    PSAssignee = PSAssignee.replace("-", " ");
                    var arr = PSAssignee.split(' ');
                    var first = arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                    if (arr.length > 1) {
                        var second = arr[1].charAt(0).toUpperCase() + arr[1].slice(1);
                        if (second !== "Tickets") {
                            PSAssignee = first + " " + second;
                        } else {
                            PSAssignee = first;
                        }
                    } else {
                        PSAssignee = first;
                    }
                    if (PSAssignee === "") {
                        PSAssignee = "None";
                    }
                    solvedCloud.tickets[i].PSAssignee = PSAssignee;
                    //solvedCloud.tickets[i].PSAssignee2=PSAssignee2;
                    solvedCloud.tickets[i].Severity = severity;
                    var createdTime = solvedCloud.tickets[i].CreatedAt;
                    var currentTime = new Date();
                    var updatedTime = solvedCloud.tickets[i].UpdatedAt;
                    var localDate = new Date(createdTime);
                    var updatedNew = new Date(updatedTime);
                    var CDate = "" + localDate.getDate() + "/" + (localDate.getMonth() + 1) + "/" + (localDate.getYear() + 1900);
                    var lDateString = localDate.toString();
                    var CTime = lDateString.substr(16, 8);
                    var createdDateTime = CDate + " " + CTime;
                    var UDate = "" + updatedNew.getDate() + "/" + (updatedNew.getMonth() + 1) + "/" + (updatedNew.getYear() + 1900);
                    var uString = updatedNew.toString();
                    var UTime = uString.substr(16, 8);
                    var updatedDateTime = UDate + " " + UTime;
                    var date = new Date();
                    var hours = Math.abs(date - localDate) / 36e5;
                    days = hours / 24;
                    days = Math.round(days * 10) / 10;
                    days = days.toString();
                    solvedCloud.tickets[i].days = days;
                    //  solvedCloud.tickets[i].CreatedAt=createdDateTime;
                    // solvedCloud.tickets[i].UpdatedAt=updatedDateTime;
                }
                arrToSetSegData[0].push(solvedCloud.tickets);
                frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
            } else {
                temp = [];
                arrToSetSegData[0].push(temp);
            }
            break;
    }
    if (arrToSetSegData[0][1].length !== 0) {
        flxRowTemp.forceLayout();
        frmDashboard.flxIndicators.opacity = 0.3;
        if (flxId === "flxS1" || flxId === "flxS2" || flxId === "flxS3") {
            frmDashboard.flxPopupLead.setVisibility(true);
            frmDashboard.flxPopupLead.forceLayout();
        }
    } else {
        frmDashboard.flxIndicators.opacity = 1;
        alert("Sorry there are no tickets to display");
    }
} //Type your code here