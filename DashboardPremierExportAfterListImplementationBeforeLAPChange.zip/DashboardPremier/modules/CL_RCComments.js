//Type your code here
clRCPopupCse=[];
clRCPopupProduct=[];
clRCPopupCloud=[];

clSolPopupCse=[];
clSolPopupProduct=[];
clSolPopupCloud=[];


function setRcCommentsForSelectedCustomer(){
        es6Testing();
         tempRcCse = returnRcSelectedCustomerTickets(rootCausePopupCse); 
         tempRcProduct = returnRcSelectedCustomerTickets(rootCausePopupProduct);
         tempRcCloud = returnRcSelectedCustomerTickets(rootCausePopupCloud);
        
         tempSolCse = returnRcSelectedCustomerTickets(solutionPopupCse);
         tempSolProduct = returnRcSelectedCustomerTickets(solutionPopupProduct);
         tempSolCloud = returnRcSelectedCustomerTickets(solutionPopupCloud);
    
          clRCPopupCse = tempRcCse;
          clRCPopupProduct = tempRcProduct; 
          clRCPopupCloud = tempRcCloud;
             
          clSolPopupCse = tempSolCse;
          clSolPopupProduct = tempSolProduct;
          clSolPopupCloud = tempSolCloud;
  
          frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCCse.lblRCCse1.text=clRCPopupCse.length;
          frmDashboard.flxQualityIndicators.flxSolutionList.flxSolCse.lblSolCse1.text=clSolPopupCse.length;
  
          frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCProduct.lblRCProduct1.text=clRCPopupProduct.length;
          frmDashboard.flxQualityIndicators.flxSolutionList.flxSolProduct.lblSolProduct1.text=clSolPopupProduct.length;
  
  
          frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCCloud.lblRCCloud1.text=clRCPopupCloud.length;
          frmDashboard.flxQualityIndicators.flxSolutionList.flxSolCloud.lblSolCloud1.text=clSolPopupCloud.length;
      
          frmDashboard.flxQualityIndicators.flxRootCause.lblRootCauseCount.text=clRCPopupCse.length+clRCPopupProduct.length+clRCPopupCloud.length;
          frmDashboard.flxQualityIndicators.flxSolution.lblSolutionCount.text=clSolPopupCse.length+clSolPopupProduct.length+clSolPopupCloud.length;  
}


function returnRcSelectedCustomerTickets(arr){
  temp=[];
  for(m=0;m<arr.length;m++)
        {
          
          for(n=0;n<monthTicketsSolvedCse.length;n++)
            {
              if(arr[m]===monthTicketsSolvedCse[n].ticketId)
                {
                  if(selectedCustomer === monthTicketsSolvedCse[n].CName || selectedCustomer === monthTicketsSolvedCse[n].CAccountName)
                    {
                      temp.push(monthTicketsSolvedCse[n].ticketId);
                    }
                  
                  break;
                }
              
            }
          
        }
  return temp;
}

function es6Testing()
{
  a=10;
  if(true)
    {
      let a=20;
      kony.print("a value inside is:"+a);
    }
  kony.print("a value outsid is:"+a);
}