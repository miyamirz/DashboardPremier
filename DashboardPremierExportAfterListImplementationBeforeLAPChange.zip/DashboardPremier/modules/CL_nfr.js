//Type your code here

function nfrForCustomerList()
{
   var criticalTicketsBreachedArr1=criticalTicketsBreached1(criticalTicketsDummyGlobal);
    var highTicketsBreachedArr1=highTicketsBreached1(highTicketsDummyGlobal);    
    var mediumTicketsBreachedArr1=mediumTicketsBreached1(mediumTicketsDummyGlobal);
    var lowTicketsBreachedArr1=lowTicketsBreached1(lowTicketsDummyGlobal);
        
   totalTicketsBreached1=criticalTicketsBreachedArr1.length+mediumTicketsBreachedArr1.length+highTicketsBreachedArr1.length+lowTicketsBreachedArr1.length;
  
              
                
                   nfrCount+=parseInt(nfrCse.ticketsCount);
                   frbCount+=parseInt(totalTicketsBreached1);
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR0.lblNR02.text=nfrCse.ticketsCount;
                  frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB0.lblFRB02.text=totalTicketsBreached1;
                      firstResponseCseBreached=firstResponseBreachedArr;
                         firstResponseBreachedArr=[];
  
                   firstResponseProductBreached=firstResponseBreachedArr;
                   firstResponseBreachedArr=[];
                  nfrCount+=parseInt(res.ticketsCount);
                  frbCount+=parseInt(totalTicketsBreached1);
                  frmDashboard.flxIndicators.flxLeadIndicator.flxNoFirstResList.flxNR1.lblNR12.text=res.ticketsCount;
           frmDashboard.flxIndicators.flxLagIndicator.flxFirstResBreachedList.flxFRB1.lblFRB12.text=totalTicketsBreached1;
                  frmDashboard.flxLeadIndicator.flxNoFirstResponse.lblFirstResponseCount.text=nfrCount;
                  frmDashboard.flxLagIndicator.flxFirstResponseBreached.lblFirstResponseBreachedCount.text=frbCount;
                  nfrCount=0;
                   frbCount=0;
}

function clLeadTab()
{
   globalResponsesLeadLag=[]; 
   viewNumLead=0;
  nfrCount=0;
     frbCount=0;
     toBreachCount=0;
      breachedCount=0;
     mttrCount=0;
      cseOpenPendingHours=0;
     cloudOpenPendingHours=0;
    productOpenPendingHours=0;
   overallPremiumHours=0;
  
  L2AutoSolvedCount=0;
 L3AutoSolvedCount=0;
 L2AutoSolvedArr=[];
 L3AutoSolvedArr=[];
 autoSolvedL3=[];
 autoSolvedL2=[];
  
  interactionsCSE=[];
interactionsProduct=[];
interactionsCloud=[];
  
   total=0;
  cseTotal=0;
  productTotal=0;
  cloudTotal=0;
  
  getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
}