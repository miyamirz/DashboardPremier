//Type your code here

function   toSetCLDataForCountBasedResponse(selectedCustomer)
  {
               openCount=0;
               pendingCount=0;
               solvedCount=0;
                if(openCseInitial.ticketsCount!==null && openCseInitial.ticketsCount!=="null")
                {
                         var open=matchSelectedCustomerInResponse(openCseInitial);
                         openCse=open[0];
                         openCseCount=open[1];
                        if(typeof openCseCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO1.lblO12.text=openCseCount.toString();
                           openCount=openCseCount;
                          }
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO1.lblO12.text="-";
                    openCount+=0;
                  } 
               
               if(openProductInitial.ticketsCount!==null && openProductInitial.ticketsCount!=="null")
                {
                         var openP=matchSelectedCustomerInResponse(openProductInitial);
                            openProduct=openP[0];
                           openProductCount=openP[1];
                        if(typeof openProductCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO2.lblO22.text=openProductCount.toString();
                           openCount+=openProductCount;
                          }
                }
                else
                  {
                     frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO2.lblO22.text="-";
                    openCount+=0;
                  } 
    
               if(openCloudInitial.ticketsCount!==null && openCloudInitial.ticketsCount!=="null")
                {
                         var openC=matchSelectedCustomerInResponse(openCloudInitial);
                              openCloud=openC[0];
                              openCloudCount=openC[1];
                              
                        if(typeof openCloudCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO3.lblO32.text=openCloudCount.toString();
                            
                           openCount+=openCloudCount;
                           frmDashboard.flxOpen.lblOpenCount.text=openCount;
                          }
                  
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO3.lblO32.text="-";
                    openCount+=0;
                    frmDashboard.flxOpen.lblOpenCount.text=openCount;
                  } 
    
    
                if(pendingCseInitial.ticketsCount!==null && pendingCseInitial.ticketsCount!=="null")
                {
                         var pending=matchSelectedCustomerInResponse(pendingCseInitial);
                              pendingCse=pending[0];
                              pendingCseCount=pending[1];
                             
                        if(typeof pendingCseCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP1.lblP12.text=pendingCseCount.toString();
                           pendingCount=pendingCseCount;
                          }
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP1.lblP12.text="-";
                    pendingCount+=0;
                  } 
               
               if(pendingProductInitial.ticketsCount!==null && pendingProductInitial.ticketsCount!=="null")
                {
                         var pendingP=matchSelectedCustomerInResponse(pendingProductInitial);
                                pendingProduct=pendingP[0];
                                pendingProductCount=pendingP[1];
                        if(typeof pendingProductCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP2.lblP22.text=pendingProductCount.toString();
                           pendingCount+=pendingProductCount;
                          }
                }
                else
                  {
                     frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP2.lblP22.text="-";
                    pendingCount+=0;
                  } 
    
               if(pendingCloudInitial.ticketsCount!==null && pendingCloudInitial.ticketsCount!=="null")
                {
                         var pendingC=matchSelectedCustomerInResponse(pendingCloudInitial);
                                pendingCloud=pendingC[0];
                                pendingCloudCount=pendingC[1];
                        if(typeof pendingCloudCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP3.lblP32.text=pendingCloudCount.toString();
                            
                           pendingCount+=pendingCloudCount;
                           frmDashboard.flxPending.lblPendingCount.text=pendingCount;
                          }
                  
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP3.lblP32.text="-";
                    pendingCount+=0;
                    frmDashboard.flxPending.lblPendingCount.text=pendingCount;
                  }
    
                if(solvedCseInitial.ticketsCount!==null && solvedCseInitial.ticketsCount!=="null")
                {
                         var solved=matchSelectedCustomerInResponse(solvedCseInitial);
                             solvedCse=solved[0];
                              solvedCseCount=solved[1];
                        if(typeof solvedCseCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS1.lblS12.text=solvedCseCount.toString();
                           solvedCount=solvedCseCount;
                          }
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS1.lblS12.text="-";
                    solvedCount+=0;
                  } 
               
               if(solvedProductInitial.ticketsCount!==null && solvedProductInitial.ticketsCount!=="null")
                {
                         var solvedP=matchSelectedCustomerInResponse(solvedProductInitial);
                              solvedProduct=solvedP[0];
                              solvedProductCount=solvedP[1];
                        if(typeof solvedProductCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS2.lblS22.text=solvedProductCount.toString();
                           solvedCount+=solvedProductCount;
                          }
                }
                else
                  {
                     frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS2.lblS22.text="-";
                    solvedCount+=0;
                  } 
    
               if(solvedCloudInitial.ticketsCount!==null && solvedCloudInitial.ticketsCount!=="null")
                {
                         var solvedC=matchSelectedCustomerInResponse(solvedCloudInitial);
                             solvedCloud=solvedC[0];
                                solvedCloudCount=solvedC[1];
                        if(typeof solvedCloudCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS3.lblS32.text=solvedCloudCount.toString();
                            
                           solvedCount+=solvedCloudCount;
                           frmDashboard.flxSolved.lblSolvedCount.text=solvedCount;
                          }
                  
                }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS3.lblS32.text="-";
                    solvedCount+=0;
                    frmDashboard.flxSolved.lblSolvedCount.text=solvedCount;
                  }
                getGraphData();
    //----------------Negative Feedback---------
    
     if(nfbCseInitial.ticketsCount!==null && nfbCseInitial.ticketsCount!=="null")
                {
                         var nfb=matchSelectedCustomerInResponse(nfbCseInitial);
                               nfbCse=nfb[0];
                              nfbCseCount=nfb[1];
                        if(typeof nfbCseCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB0.lblNFB02.text=nfbCseCount.toString();
                           nbCount=nfbCseCount;
                          }
                }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB0.lblNFB02.text="-";
                    nbCount+=0;
                  } 
    
    if(nfbProductInitial.ticketsCount!==null && nfbProductInitial.ticketsCount!=="null")
                {
                         var nfbP=matchSelectedCustomerInResponse(nfbProductInitial);
                              nfbProduct=nfbP[0];
                              nfbProductCount=nfbP[1];
                        if(typeof nfbProductCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB1.lblNFB12.text=nfbProductCount.toString();
                            
                           nbCount+=nfbProductCount;
                           frmDashboard.flxLagIndicator.flxNegativeFeedback.lblNFBCount.text=nbCount;
                          }
                  
                }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB1.lblNFB12.text="-";
                    nbCount+=0;
                    frmDashboard.flxLagIndicator.flxNegativeFeedback.lblNFBCount.text=nbCount;
                  }
               
               
       //-------ESCALATIONS-------------------------------------------------->
    
    if(escCseInitial.ticketsCount!==null && escCseInitial.ticketsCount!=="null")
                {
                         var esc=matchSelectedCustomerInResponse(escCseInitial);
                                escCse=esc[0];
                              escCseCount=esc[1];
                        if(typeof escCseCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCse.lblESCCse1.text=escCseCount.toString();
                           escCount=escCseCount;
                          }
                }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCse.lblESCCse1.text="-";
                    escCount+=0;
                  } 
               
               if(escProductInitial.ticketsCount!==null && escProductInitial.ticketsCount!=="null")
                {
                         var escP=matchSelectedCustomerInResponse(escProductInitial);
                  
                             escProduct=escP[0];
                              escProductCount=escP[1];
                        if(typeof escProductCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsProduct.lblESCProduct1.text=escProductCount.toString();
                           escCount+=escProductCount;
                          }
                }
                else
                  {
                     frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsProduct.lblESCProduct1.text="-";
                    escCount+=0;
                  } 
    
               if(escCloudInitial.ticketsCount!==null && escCloudInitial.ticketsCount!=="null")
                {
                         var escC=matchSelectedCustomerInResponse(escCloudInitial);
                             escCloud=escC[0];
                                escCloudCount=escC[1];
                               
                        if(typeof escCloudCount != 'undefined')
                          {
                           frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCloud.lblESCCloud1.text=escCloudCount.toString();
                            
                           escCount+=escCloudCount;
                           frmDashboard.flxIndicators.flxLagIndicator.flxEscalations.lblEscalationsCount.text=escCount;
                          }
                  
                }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCloud.lblESCCloud1.text="-";
                    escCount+=0;
                    frmDashboard.flxIndicators.flxLagIndicator.flxEscalations.lblEscalationsCount.text=escCount;
                  }
    
  }

function matchSelectedCustomerInResponse(res)
   {
          tempRes={};
          //tempRes.ticketsCount=res.ticketsCount;
          tempRes.tickets=[];
          count=0;
             if(res.ticketsCount!=="0"){
               for(var i=0;i<res.tickets.length;i++)
                  {
                   var customArr=res.tickets[i].CustomField;
                        for(var k=0;k<customArr.length;k++)
                          {
                           if(customArr[k].id===21277110)
                              {
                                 custName=customArr[k].value;
                                 break;
                              }
                          }
                        if(custName!==null)
      		               CustomerName=custName.trim();
   					    else
       			           CustomerName="none";
                       if(selectedCustomer === CustomerName)
                         {
                           tempRes.tickets.push(res.tickets[i]);
                           count++;
                         }
                  }
                 tempRes.ticketsCount=count.toString();
                return [tempRes,count];
             }
           tempRes.ticketsCount=count.toString();
                return [tempRes,count];
}