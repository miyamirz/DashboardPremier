//Type your code here

function CSEAssignee(token)
{
  var name;
  switch(token)
    {
      case "arif":
                   name="Arif";
                   break;
       case "harish_tammineddi":
                   name="Harish Tammineddi";
                   break;
        case "kushal":
                   name="Kushal";
                   break;
        case "naresh_nalamolu":
                   name="Naresh Nalamolu";
                   break;
          case "rajkumar":
                   name="Raj Kumar";
                   break;
        case "sreekanth_madamanchi":
                   name="Sreekanth Madamanchi";
                   break;
        case "srikanth_donavalli":
                   name="Srikanth Donavalli";
                   break;
         case "suresh_balivada":
                   name="Suresh Balivada";
                   break;
          case "sana-tickets":
                   name="Syed Sanaulla";
                   break;
        case "thilak":
                   name="Thilak Yerra";
                   break;
        case "mallikarjuna_anegondi":
                   name="Mallikarjuna Anegondi";
                   break;
         case "pothuraju_gorre":
                   name="Pothuraju Gorre";
                   break;
        case "nishtha_sood":
                   name="Nishtha Sood";
                   break;
        case "naveen_dengani":
                   name="Naveen Dengani";
                   break;
         case "anurag_wanjari":
                   name="Anurag Wanjari";
                   break;
           case "guru_pulipati":
                   name="Guru Pulipati";
                   break;
         case "manish_khemka":
                   name="Manish Khemka";
                   break;
         case "nagaraju_yanamadala":
                   name="Nagaraju Yanamadala";
                   break;
        case "naveen_kuppili":
                   name="Naveen Kuppili";
                   break;
        case "radhika_tickets":
                   name="Radhika Yennam";
                   break;
        case "rashmi":
                   name="Rashmi";
                   break;
          case "ravikumar":
                   name="Ravi Kumar";
                   break;
        case "ravi_pyreddy":
                   name="Ravi Pyreddy";
                   break;
         case "ravinder_beecham":
                   name="Ravinder Beecham";
                   break;
        case "rojalin santhoshn":
                   name="Rojalin Santhoshn";
                   break;
        case "jabiulla":
                   name="Jabiulla";
                   break;
        case "sridhar_thru":
                   name="Sridhar Thru";
                   break;
        case "srikanthj":
                   name="Srikanth J";
                   break;
        case "venkat_tadepalli":
                   name="Venkat Tadepalli";
                   break;
         case "sirisha_m":
                   name="Sirisha Munala";
                   break;
         case "johnvinodh_talluri":
                   name="JohnVinodh Talluri";
                   break;
        case "madhuri_choutkur":
                   name="Madhuri Choutkur";
                   break;
         case "lakshmi_vajrapu":
                   name="Lakshmi Vajrapu";
                   break;
      default:
                name=token;
               break;
         
    }
  
  return name;
}