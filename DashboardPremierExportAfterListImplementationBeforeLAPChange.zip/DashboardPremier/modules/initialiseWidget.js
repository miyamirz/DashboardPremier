//Type your code here
function callLineChart()
{
  var a='A';
  var b='B';
  frmDashboard.lineChart.chartData={
    "premierValue":[0,3.5,6,9],
    "rowNames": {"values": ["Row1", "Row2", "Row3", "Row4","Row5","Row6", "Row7", "Row8"]   },
             "columnNames": {  "values": [a, b]  },
             "data": {
                  [a] : [23, 44,56, 87, 77, 59, 11, 22],
                    [b] : [29, 50, 34, 54, 46 ,67, 38, 89],
                    
                }
  };
  frmDashboard.lineChart.chartProperties={
    
    
    "chartHeight": 500,
    "layerArea": {
                "background": {
                                "color": ["transparent"],
                              },
                  "border":{
                               "color": ["black"], 
                                "width": [0],
                           }
                 },

    "legend": {
                      
                         "font": {
                                "size": [12],
                                "family": ["Verdana"],
                                "style": ["normal"],
                                "color": ["0xaaaaaaff"]
                         },
                          "position": "top", 
                          "alignment": "left",    //to be set
                   
            },
          "axis": {
                      "xAxis": {
                        "visible":true,
                            "title": {
                              "visible":true,
                                "text": "City",
                                "font": {
                                    "size": [14],
                                    "family": ["Verdana"],
                                    "style": ["Bold"],
                                    "color": ["black"]
                                      },
                                },
//                              "scale": {
//                                     "minValue": 20,
//                                     "maxValue": 150,
//                                 },
                            "axisLine": {
                      				"line": {
                                   "color": ["black"],}
                          
						     },
                              "labels": {
                                "visible":true,
                                  "orientationAngle": 30,
                                      "font": {
                                          "size": [12],
                                          "family": ["Verdana"],
                                          "style": ["bold"],
                                          "color": ["0x000000ff"],
                                          "transparency": [0]
                                      }
                              }
                          },
                      "yAxis": {
                        "visible":true,
                             "title": {
                               "visible":true,
                              "text": "Population",
                              "font": {
                                  "size": [16],
                                  "family": ["Verdana"],
                                  "style": ["normal"],
                                  "color": ["black"]
                              },
                             },
//                         "scale": {
//                               "minValue": 0,
//                               "maxValue": 150,
//                           },
                           "axisLine": {
                      				"line": {
                                   "color": ["black"],},
                          
						},
                              "labels": {
                                "visible":true,
                                      "font": {
                                          "size": [20],
                                          "family": ["Verdana"],
                                          "style": ["bold"],
                                          "color": ["0x000000ff"],
                                          "transparency": [10]
                                      }
                              }
                          }
                },
        "grid": {  // "type": ["xAxisMinorGrid", "yAxisMinorGrid"],
                      "xAxisMinorGrid": {
                          "line": {
                              "color": ["transparent"]
                          }
                      },
                      "yAxisMinorGrid": {
                          "line": {
                              "color": ["transparent"]
                          }
                      }
            },
        "title": {
                          "visible": true,
                          "text": "How much ??",
                          "font": {
                              "size": ["20"],
                              "family": ["Verdana"],
                              "style": ["bold"],
                              "color": ["0x000000ff"],    
                          },
                          "position": "top",    
                        
                },
    "lineChart" :{
              
                  "animations": {
                          "onInitAnimation": true,
                  },
              
                  "line": {
                            "color": ["black","red","blue"],
                            "width": [2],
                  },
                  "plotPoints": {
                              "visible": true,
                             "marker": {
                                "type": ["circle"],
                              },
                              "color": ["0x2a99ceff"],
                              "size": [8],
                  },
                  "dataLabels": {
                                  
                                    "font": {
                                      "size": [14],
                                      "family": ["Verdana"],
                                      "style": ["bold"],
                                      "color": ["white"],
                                      "transparency": [34]    
                                    },
                  },
      }
        };
  frmDashboard.lineChart.chartEvents={
      "onTap": "onClickOfLine",
  												};
}

function callGaugeChart()
{
  frmDashboard.gauge.chartData={
    "premierValue":[3.5,6,9,14]
  };
}
