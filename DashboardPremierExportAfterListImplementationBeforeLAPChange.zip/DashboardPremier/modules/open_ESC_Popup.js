//Type your code here



function showOpenPopup(context)
{
  
  var flxId=context.constructorList[0].id;
  var i;
  
  frmDashboard.flxPopupLead.segPopupLead.widgetDataMap={
    
    slblTicket:"slblTicket",
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",   
    slblPsAssignee:"slblPsAssignee",
    slblDynamic:"slblDynamic",
    slblStatus:"slblStatus",
    
    lblTicket:"valId",
    lblSeverity:"Severity",
    lblCustName:"CName",
    lblCreated:"days",  
    lblPsAssignee:"PSAssignee",
    lblDynamic:"PSAssignee2", 
    lblStatus:"Status"
   
  };
   frmDashboard.flxPopupLag.segPopupLag.widgetDataMap={
    
    slblTicket:"slblTicket", 
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",    
    slblPsAssignee:"slblPsAssignee",
    slblDynamic:"slblDynamic", 
    slblStatus:"slblStatus",
            
    lblTicket:"valId",
    lblSeverity:"Severity",
    lblCustName:"CName",
    lblCreated:"days",
    lblPsAssignee:"PSAssignee",
    lblDynamic:"PSAssignee2",
    lblStatus:"Status"
    
  };
 
    arrToSetSegData=[  
    					[ 
                          {
                             slblTicket:"Ticket Id",
  							 slblSupportPlan:"Support Plan",
 							 slblSeverity:"Severity",
   							 slblCustName:"Customer Name",
  							 slblCreated:"Age(Days)",
  							 slblUpdated:"UpdatedAt",
  							 slblPsAssignee:"CSE Assignee",
                             slblStatus:"Status",
                                
                          },
                           
                        ]
    
                   ];
  switch(flxId)
    {
      case "flxO1":   
        
                     if(openCse.ticketsCount!=="0"){                    
                         arrToSetSegData[0][0].slblDynamic="Assignee";
                        for(i=0;i<openCse.tickets.length;i++)
                          {
                                if(openCse.tickets[i].AssigneeId === 14272801548)
                                  {
                                    assigneeKind="BDE";
                                  }
                                else
                                  {
                                    assigneeKind="CSE";
                                  }                            
                                       custName="";
                                       psAssign="";
      									 supPlan="";
                                                    
                                     valId=openCse.tickets[i].ticketId;
                        		 openCse.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                            
                                            var customArr=openCse.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                        {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                       else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                    
                                                        else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    
                                                    }
												     if(ETA!== null && ETA!=="")
                                                       {
                                                         openCse.tickets[i].ETA=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         openCse.tickets[i].ETA="";
                                                      }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    if(assigneeKind==="BDE")
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                        PSAssignee2="Kony BDE Product Support";
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                        PSAssignee2="Kony Product Support";
                                                      }
                                                    

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     openCse.tickets[i].CName=CustomerName;
                                                     openCse.tickets[i].SupportPlan=SupportPlan;
                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
												if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            
                                            openCse.tickets[i].PSAssignee=PSAssignee;
                                            openCse.tickets[i].PSAssignee2=PSAssignee2;
                          					   openCse.tickets[i].Severity=severity;
                            
                                   var createdTime=openCse.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=openCse.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         openCse.tickets[i].days=days;
                                        
//                                          openCse.tickets[i].CreatedAt=createdDateTime;
//                                          openCse.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
                          
                            arrToSetSegData[0].push(openCse.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                    }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                          break;
        
       
        case "flxO2": 
       				 if(openProduct.ticketsCount!=="0"){
                           arrToSetSegData[0][0].slblDynamic="ETA";
                        for(i=0;i<openProduct.tickets.length;i++)
                          {
                            
//                                if(openProduct.tickets[i].AssigneeId === 14272801548)
//                                   {
//                                     openProduct.tickets[i].AssigneeKind="BDE";
//                                   }
//                                 else
//                                   {
//                                     openProduct.tickets[i].AssigneeKind="CSE";
//                                   }
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                   valId=openProduct.tickets[i].ticketId;
                        		 openProduct.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=openProduct.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         openProduct.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         openProduct.tickets[i].PSAssignee2="-";
                                                      }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    if(psAssign2==="")
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                         
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                      }
//                                                       PSAssignee2="Kony L3 Product Support";
                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     openProduct.tickets[i].CName=CustomerName;
                                                     openProduct.tickets[i].SupportPlan=SupportPlan;
                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
   												if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            
                            				
                            
                                            openProduct.tickets[i].PSAssignee=PSAssignee;
                                           // openProduct.tickets[i].PSAssignee2=PSAssignee2;
                          					   openProduct.tickets[i].Severity=severity;
                            
                                   var createdTime=openProduct.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=openProduct.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
									  days = Math.round( days * 10 ) / 10;
                       		          days=days.toString();
                                         openProduct.tickets[i].days=days;


                                }
        
                            arrToSetSegData[0].push(openProduct.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                            }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                    break;
        
          case "flxO3":
                          if(openCloud.ticketsCount!=="0"){
                             arrToSetSegData[0][0].slblDynamic="ETA";
                        for(i=0;i<openCloud.tickets.length;i++)
                          {
                            
//                                 if(openCloud.tickets[i].AssigneeId === 14272801548)
//                                   {
//                                     openCloud.tickets[i].AssigneeKind="BDE";
//                                   }
//                                 else
//                                   {
//                                     openCloud.tickets[i].AssigneeKind="CSE";
//                                   }
//                              arrToSetSegData[0][0].slblAssigneeKind="";
                                   custName="";
                                       psAssign="";
      									 supPlan="";
      										  valId=openCloud.tickets[i].ticketId;
                        		 openCloud.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";								
                                            var customArr=openCloud.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                     else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         openCloud.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         openCloud.tickets[i].PSAssignee2="-";
                                                      }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
//                                                     if(psAssign2==="")
                                                      //{
                                                        if(psAssign2==="")
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                         
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                      }
                                                     // PSAssignee2="Kony Cloud ";
                                                        
//                                                       }
//                                                     else
//                                                       {
//                                                         PSAssignee=psAssign2.trim();
//                                                      }

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     openCloud.tickets[i].CName=CustomerName;
                                                     openCloud.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                                 if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }

                                            openCloud.tickets[i].PSAssignee=PSAssignee;
                            				//openCloud.tickets[i].PSAssignee2=PSAssignee2;
                                           
                          					   openCloud.tickets[i].Severity=severity;
                            
                                   var createdTime=openCloud.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=openCloud.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         openCloud.tickets[i].days=days;
                                        // openCloud.tickets[i].CreatedAt=createdDateTime;
                                      //   openCloud.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(openCloud.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                         }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                    break;
        
        case "flxEscalationsCse":
                          if(escCse.ticketsCount!=="0"){
                             arrToSetSegData[0][0].slblDynamic="Assignee";
                        for(i=0;i<escCse.tickets.length;i++)
                          {
                                 escCse.tickets[i].ETA="";
                                  if(escCse.tickets[i].AssigneeId === 14272801548)
                                  {
                                    assigneeKind="BDE";
                                  }
                                else
                                  {
                                    assigneeKind="CSE";
                                  }
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
      										  valId=escCse.tickets[i].ticketId;
                        		 escCse.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";								
                                            var customArr=escCse.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
                                                    
                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                   if(assigneeKind==="BDE")
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                        PSAssignee2="Kony BDE Product Support"
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                        PSAssignee2="Kony Product Support";
                                                      }
                                                    

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     escCse.tickets[i].CName=CustomerName;
                                                     escCse.tickets[i].SupportPlan=SupportPlan;

                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                             PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                                 if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            
                                            escCse.tickets[i].PSAssignee=PSAssignee;
                                            escCse.tickets[i].PSAssignee2=PSAssignee2;
                          					   escCse.tickets[i].Severity=severity;
                            
                                   var createdTime=escCse.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=escCse.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         escCse.tickets[i].days=days;
                                        // escCse.tickets[i].CreatedAt=createdDateTime;
                                      //   escCse.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(escCse.tickets);
      					  frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
                         }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                    break;
        case "flxEscalationsProduct":
                          if(escProduct.ticketsCount!=="0"){
                             arrToSetSegData[0][0].slblDynamic="ETA";
                        for(i=0;i<escProduct.tickets.length;i++)
                          {
                             
//                                if(escProduct.tickets[i].AssigneeId === 14272801548)
//                                   {
//                                     escProduct.tickets[i].AssigneeKind="BDE";
//                                   }
//                                 else
//                                   {
//                                     escProduct.tickets[i].AssigneeKind="CSE";
//                                   }
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
      										  valId=escProduct.tickets[i].ticketId;
                        		 escProduct.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";								
                                            var customArr=escProduct.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                       else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                     else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         escProduct.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         escProduct.tickets[i].PSAssignee2="-";
                                                      }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    if(psAssign2==="")
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                      
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                      }
                                                    //  PSAssignee2="Kony L3 Product Support";
                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     escProduct.tickets[i].CName=CustomerName;
                                                     escProduct.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                            					PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                             if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                                 if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                            	           
                                            
                                            	
                                            escProduct.tickets[i].PSAssignee=PSAssignee;
                                          //  escProduct.tickets[i].PSAssignee2=PSAssignee2;
                          					   escProduct.tickets[i].Severity=severity;
                            
                                   var createdTime=escProduct.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=escProduct.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         escProduct.tickets[i].days=days;
                                        // escProduct.tickets[i].CreatedAt=createdDateTime;
                                      //   escProduct.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(escProduct.tickets);
      					  frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
                         }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                    break;
        case "flxEscalationsCloud":
                          if(escCloud.ticketsCount!=="0"){
                            arrToSetSegData[0][0].slblDynamic="ETA";
                        for(i=0;i<escCloud.tickets.length;i++)
                          {
                              
                            
//                                  if(escCloud.tickets[i].AssigneeId === 14272801548)
//                                   {
//                                     escCloud.tickets[i].AssigneeKind="BDE";
//                                   }
//                                 else
//                                   {
//                                     escCloud.tickets[i].AssigneeKind="CSE";
//                                   }                           
                                   custName="";
                                       psAssign="";
      									 supPlan="";
      										  valId=escCloud.tickets[i].ticketId;
                        		 escCloud.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";								
                                            var customArr=escCloud.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                      else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         escCloud.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         escCloud.tickets[i].PSAssignee2="-";
                                                      }
                          
                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
//                                                    if(psAssign2==="")
//                                                       {
                                                        PSAssignee=psAssign.trim();
                                                       //  PSAssignee2="Kony Cloud";
                                                         
//                                                       }
//                                                     else
//                                                       {
//                                                         PSAssignee=psAssign2.trim();
//                                                       }

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     escCloud.tickets[i].CName=CustomerName;
                                                     escCloud.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                            					PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                                 if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                                            
                                            escCloud.tickets[i].PSAssignee=PSAssignee;
                                            // escCloud.tickets[i].PSAssignee2=PSAssignee2;
                          					   escCloud.tickets[i].Severity=severity;
                            
                                   var createdTime=escCloud.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=escCloud.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         escCloud.tickets[i].days=days;
                                        // escCloud.tickets[i].CreatedAt=createdDateTime;
                                      //   escCloud.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(escCloud.tickets);
      					  frmDashboard.flxPopupLag.segPopupLag.setData(arrToSetSegData);
                         }
                       else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                    break;
        
        
        
        
        
        
          }
  
  
  
   if(arrToSetSegData[0][1].length!==0)
   {

  flxRowTemp.forceLayout();
     frmDashboard.flxIndicators.opacity=0.1;
     frmDashboard.flxIndicators.forceLayout();
   if(flxId==="flxO1" || flxId==="flxO2" || flxId==="flxO3")   
     {
   frmDashboard.flxPopupLead.setVisibility(true);
   frmDashboard.flxPopupLead.forceLayout();
     }
   else if(flxId==="flxEscalationsCse" || flxId==="flxEscalationsProduct" || flxId==="flxEscalationsCloud")   
     {
   frmDashboard.flxPopupLag.setVisibility(true);
   frmDashboard.flxPopupLag.forceLayout();
     }
  
  
     
   }
  else
    {
       frmDashboard.flxIndicators.opacity=1;
      alert("Sorry there are no tickets to display");
    }
  
  
 
}