//Type your code here

//Type your code here



function showPendingPopup(context)
{
  
  var flxId=context.constructorList[0].id;
  var i;
  
  frmDashboard.flxPopupLead.segPopupLead.widgetDataMap={
    
    slblTicket:"slblTicket",
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",   
    slblPsAssignee:"slblPsAssignee",
    slblDynamic:"slblDynamic",
    slblStatus:"slblStatus",
    
    
    lblTicket:"valId",
    lblSeverity:"Severity",
    lblCustName:"CName",
    lblCreated:"days",   
    lblPsAssignee:"PSAssignee",
    lblDynamic:"PSAssignee2",
    lblStatus:"Status",
   
  };
    arrToSetSegData=[  
    					[ 
                          {
                              slblTicket:"Ticket Id",
  							  slblSupportPlan:"Support Plan",
 							  slblSeverity:"Severity",
   							  slblCustName:"Customer Name",
  							  slblCreated:"Age(Days)",
  							  slblUpdated:"UpdatedAt",
  							  slblPsAssignee:"CSE Assignee",
                            	slblStatus:"Status",
                              
                          },
                           
                        ]
    
                   ];
  switch(flxId)
    {
      case "flxP1":
                      
                    if(pendingCse.ticketsCount!=="0"){
                          arrToSetSegData[0][0].slblDynamic="Assignee";
        					for(i=0;i<pendingCse.tickets.length;i++)
                          {
                                 pendingCse.tickets[i].ETA=""; 
                            if(pendingCse.tickets[i].AssigneeId === 14272801548)
                                  {
                                    assigneeKind="BDE";
                                  }
                                else
                                  {
                                    assigneeKind="CSE";
                                  }
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                           valId=pendingCse.tickets[i].ticketId;
                        		 pendingCse.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=pendingCse.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                       else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }                                                
                                                    }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    
                                                       if(assigneeKind==="BDE")
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                        PSAssignee2="Kony BDE Product Support"
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                        PSAssignee2="Kony Product Support";
                                                      }

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     pendingCse.tickets[i].CName=CustomerName;
                                                     pendingCse.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                               PSAssignee=PSAssignee.replace("_"," ");
                                                    PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
													if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                                          
                                            pendingCse.tickets[i].PSAssignee=PSAssignee;
                                           pendingCse.tickets[i].PSAssignee2=PSAssignee2;
                          					   pendingCse.tickets[i].Severity=severity;
                            
                                   var createdTime=pendingCse.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=pendingCse.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		 days=days.toString();
                                         pendingCse.tickets[i].days=days;
                
                                }
        
                            arrToSetSegData[0].push(pendingCse.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
    					}
  					    else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                          break;
        
       
        case "flxP2":
                        
                          if(pendingProduct.ticketsCount!=="0"){
                            arrToSetSegData[0][0].slblDynamic="ETA";
        				for(i=0;i<pendingProduct.tickets.length;i++)
                          {
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                                          valId=pendingProduct.tickets[i].ticketId;
                        		 pendingProduct.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=pendingProduct.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                       else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                   else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         pendingProduct.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         pendingProduct.tickets[i].PSAssignee2="-";
                                                      }

                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    if(psAssign2==="")
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                      
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                      }
                                                     // PSAssignee2="Kony L3 Product Support";

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     pendingProduct.tickets[i].CName=CustomerName;
                                                     pendingProduct.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                            					if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                                            
                                            pendingProduct.tickets[i].PSAssignee=PSAssignee;
                                          //  pendingProduct.tickets[i].PSAssignee2=PSAssignee2;
                          					   pendingProduct.tickets[i].Severity=severity;
                            
                                   var createdTime=pendingProduct.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=pendingProduct.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         pendingProduct.tickets[i].days=days;
                                        // pendingProduct.tickets[i].CreatedAt=createdDateTime;
                                      //   pendingProduct.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(pendingProduct.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                         }
  					    else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
                        break;
        
          case "flxP3":
                         if(pendingCloud.ticketsCount!=="0"){
                               arrToSetSegData[0][0].slblDynamic="ETA";
                        for(i=0;i<pendingCloud.tickets.length;i++)
                          {
                            
                                   custName="";
                                       psAssign="";
      									 supPlan="";
                                   valId=pendingCloud.tickets[i].ticketId;
                        		 pendingCloud.tickets[i].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
                                            var customArr=pendingCloud.tickets[i].CustomField;
                                         			    for(var k=0;k<customArr.length;k++)
                                                    {
                                                      if(customArr[k].id===77167)
                                                        {
                                                          severity=customArr[k].value;

                                                        }
                                                      else if(customArr[k].id===21277110)
                                                        {
                                                          custName=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===40952728)
                                                        {
                                                          supPlan=customArr[k].value;
                                                        }
                                                         else if(customArr[k].id===21145230)
                                                        {
                                                          psAssign=customArr[k].value;
                                                        }
                                                       else if(customArr[k].id===114094136854)
                                                        {
                                                          psAssign2=customArr[k].value;
                                                        }
                                                    else if(customArr[k].id===22618834)
                                                        {
                                                          ETA=customArr[k].value;
                                                        }
                                                    //  kony.print("iteration count in inner for loop:"+k);
                                                    }
												     if(ETA!==null && ETA!=="")
                                                       {
                                                         pendingCloud.tickets[i].PSAssignee2=ETA.toString();
                                                       }
                                                    else
                                                      {
                                                         pendingCloud.tickets[i].PSAssignee2="-";
                                                      }
                                                    severity=severity.toLowerCase();
                                                    severity=severity.trim();
                                                    if(custName!==null && custName!=="")
                                                          CustomerName=custName.trim();
                                                    else
                                                          CustomerName="none";
                                                    SupportPlan=supPlan.trim();
                                                    if(psAssign2==="")
                                                      {
                                                        PSAssignee=psAssign.trim();
                                                         
                                                      }
                                                    else
                                                      {
                                                        PSAssignee=psAssign2.trim();
                                                      }
                                                      //PSAssignee2="Kony Cloud ";

                                                     if(SupportPlan==="supportplan_1")
                                                       {
                                                         SupportPlan="Premier";
                                                       }
                                                     else if(SupportPlan==="supportplan_1_1")
                                                       {
                                                         SupportPlan="Premier Plus";
                                                       }

                                                     pendingCloud.tickets[i].CName=CustomerName;
                                                     pendingCloud.tickets[i].SupportPlan=SupportPlan;



                                              PSAssignee=PSAssignee.trim();
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("_"," ");
                                              PSAssignee=PSAssignee.replace("-"," ");
                                              var arr = PSAssignee.split(' ');

                                              var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
                                              if(arr.length>1)
                                              {
                                              var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

                                              if(second!=="Tickets" || second!=="Bde")
                                              {
                                              PSAssignee=first+" "+second;
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
                                              }
                                              else
                                              {
                                              PSAssignee=first;
                                              }
											if(PSAssignee==="")
                                                   {
                                                     PSAssignee="None";
                                                   }
                                           
                                            pendingCloud.tickets[i].PSAssignee=PSAssignee;
                                            // pendingCloud.tickets[i].PSAssignee2=PSAssignee2;
                                           
                          					   pendingCloud.tickets[i].Severity=severity;
                            
                                   var createdTime=pendingCloud.tickets[i].CreatedAt;
                                   var currentTime=new Date();

                                   var updatedTime=pendingCloud.tickets[i].UpdatedAt;

                                      var localDate = new Date(createdTime);
                                  var updatedNew=new Date(updatedTime);


                                          var CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
                                           var lDateString=localDate.toString();
                                          var CTime=lDateString.substr(16,8);
                                          var createdDateTime=CDate+" "+CTime;

                                         var UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
                                         var uString=updatedNew.toString();
                                          var UTime=uString.substr(16,8);
                                          var updatedDateTime=UDate+" "+UTime;

                                  var date= new Date();
                                  var hours = Math.abs(date - localDate) / 36e5;
                                      days=hours/24;
										 days = Math.round( days * 10 ) / 10;
                       		days=days.toString();
                                         pendingCloud.tickets[i].days=days;
                                      //   pendingCloud.tickets[i].CreatedAt=createdDateTime;
                                      //   pendingCloud.tickets[i].UpdatedAt=updatedDateTime;

                            

                                }
        
                            arrToSetSegData[0].push(pendingCloud.tickets);
      					  frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                   
							}
  					    else
                         {
                           temp=[];
                         arrToSetSegData[0].push(temp);

                         }
						break;
        
        
        
        
        
        
          }
  
  
  
   if(arrToSetSegData[0][1].length!==0)
   {

  flxRowTemp.forceLayout();
     frmDashboard.flxIndicators.opacity=0.1;
   if(flxId==="flxP1" || flxId==="flxP2" || flxId==="flxP3")   
     {
   frmDashboard.flxPopupLead.setVisibility(true);
   frmDashboard.flxPopupLead.forceLayout();
     }
  
     
   }
  else
    {
       frmDashboard.flxIndicators.opacity=1;
      alert("Sorry there are no tickets to display");
      frmDashboard.flxIndicators.opacity=1;
    }
  
  
 
}