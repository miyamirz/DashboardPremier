//Type your code here
var resCSE=[];
var resProduct=[];
var resCloud=[];
var repliesCSE=[];
var repliesProduct=[];
var repliesCloud=[];
function showInteractionsPopup(context)
{
  var flxId=context.constructorList[0].id;
  var m,n;
  
  
 for(var z=0;z<globalResponsesLeadLag.length;z++)
   {
     if(globalResponsesLeadLag[z].viewNumber==="114115512134")
       {
         resCSE=globalResponsesLeadLag[z].tickets;
         
       }
     else if(globalResponsesLeadLag[z].viewNumber==="114115514894")
       {
         resProduct=globalResponsesLeadLag[z].tickets;
         
       }
     else if(globalResponsesLeadLag[z].viewNumber==="114115514994")
       {
         resCloud=globalResponsesLeadLag[z].tickets;
         
       }
     
   }
  
  if(flxId==="flxInteractions0")
    {
      
      for(m=0;m<interactionsCSE.length;m++)
        {
          
          for(n=0;n<resCSE.length;n++)
            {
              if(interactionsCSE[m]===resCSE[n].ticketId)
                {
                  repliesCSE.push(resCSE[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
   else if(flxId==="flxInteractions1")
    {
      
      for( m=0;m<interactionsProduct.length;m++)
        {
          
          for( n=0;n<resProduct.length;n++)
            {
              if(interactionsProduct[m]===resProduct[n].ticketId)
                {
                  repliesProduct.push(resProduct[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
  
     else if(flxId==="flxInteractions2")
    {
      
      for( m=0;m<interactionsCloud.length;m++)
        {
          
          for( n=0;n<resCloud.length;n++)
            {
              if(interactionsCloud[m]===resCloud[n].ticketId)
                {
                  repliesCloud.push(resCloud[n]);
                  break;
                }
              
            }
          
        }
      
    }
  
  
  
    frmDashboard.flxPopupLag.segPopupLag.widgetDataMap={
    
    slblTicket:"slblTicket",
    slblSeverity:"slblSeverity",
    slblCustName:"slblCustName",
    slblCreated:"slblCreated",   
    slblPsAssignee:"slblPsAssignee",
    slblDynamic:"slblDynamic",
    slblStatus:"slblStatus",
    
    lblTicket:"valId",
    lblSeverity:"Severity",
    lblCustName:"CName",
    lblCreated:"days",  
    lblPsAssignee:"PSAssignee",
    lblDynamic:"PSAssignee2", 
    lblStatus:"Status"
  };
  
  
  arrToSetSegData=[  
    					[ 
                          {
                             slblTicket:"Ticket Id",
  							 slblSupportPlan:"Support Plan",
 							 slblSeverity:"Severity",
   							 slblCustName:"Customer Name",
  							 slblCreated:"Age(Days)",
  							 slblUpdated:"UpdatedAt",
  							 slblPsAssignee:"CSE Assignee",
                             slblStatus:"Status",
                          },
                           
                        ]
    
                   ];
  
  
    
  switch(flxId)
    {
      case "flxInteractions0":
                        arrToSetSegData[0][0].slblDynamic="Assignee";
                         prepareData(repliesCSE,"cse",callback);
//                      	
        			    repliesCSE=[];
        			 break;    
     case "flxInteractions1":
                         arrToSetSegData[0][0].slblDynamic="ETA";
                         prepareData(repliesProduct,"product",callback);
//                      	for(n=0;n<repliesProduct.length;n++)
//                        {
//                           createdTime=repliesProduct[n].CreatedAt;
//     							 currentTime=new Date();
     
//    							  updatedTime=repliesProduct[n].UpdatedAt;

//                           localDate = new Date(createdTime);
//     					updatedNew=new Date(updatedTime);
     
         
// 			CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
//              lDateString=localDate.toString();
//  		    CTime=lDateString.substr(16,8);
//             createdDateTime=CDate+" "+CTime;
     
//            UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
//            uString=updatedNew.toString();
//  		    UTime=uString.substr(16,8);
//             updatedDateTime=UDate+" "+UTime;
      
// 						date= new Date();
// 								 hours = Math.abs(date - localDate) / 36e5;
                         
//                           days=hours/24;
// 							 days = Math.round( days * 10 ) / 10;
//                          repliesProduct[n].days=days;
//                          valId=repliesProduct[n].ticketId;
                         
//                          repliesProduct[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
//                        }
//                      arrToSetSegData[0].push(repliesProduct);
//       			   frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
                       repliesProduct=[];
        			 break;  
       case "flxInteractions2":
                             arrToSetSegData[0][0].slblDynamic="ETA";
                        prepareData(repliesCloud,"cloud",callback);
//                      	for(n=0;n<repliesCloud.length;n++)
//                        {
//                           createdTime=repliesCloud[n].CreatedAt;
//     							 currentTime=new Date();
     
//    							  updatedTime=repliesCloud[n].UpdatedAt;

//                           localDate = new Date(createdTime);
//     					updatedNew=new Date(updatedTime);
     
         
// 			CDate=""+localDate.getDate()+"/"+(localDate.getMonth()+1)+"/"+(localDate.getYear()+1900) ; 
//              lDateString=localDate.toString();
//  		    CTime=lDateString.substr(16,8);
//             createdDateTime=CDate+" "+CTime;
     
//            UDate=""+updatedNew.getDate()+"/"+(updatedNew.getMonth()+1)+"/"+(updatedNew.getYear()+1900) ; 
//            uString=updatedNew.toString();
//  		    UTime=uString.substr(16,8);
//             updatedDateTime=UDate+" "+UTime;
      
// 						date= new Date();
// 								 hours = Math.abs(date - localDate) / 36e5;
                         
//                           days=hours/24;
// 							 days = Math.round( days * 10 ) / 10;
//                          repliesCloud[n].days=days;
//                          valId=repliesCloud[n].ticketId;
                         
//                          repliesCloud[n].valId="<a target='_blank' href='https://konysolutions.zendesk.com/agent/tickets/"+valId+"'>"+valId+"</a>";
//                        }
//                      arrToSetSegData[0].push(repliesCloud);
//       			   frmDashboard.flxPopupLead.segPopupLead.setData(arrToSetSegData);
        			repliesCloud=[];
        			 break; 
        
       
  
    }
  
//   if(arrToSetSegData[0][1].length!==0)
//    {
//    frmDashboard.flxIndicators.opacity=0.1;     
//      frmDashboard.flxIndicators.forceLayout();
//   flxRowTemp.forceLayout();
   
//    frmDashboard.flxPopupLead.setVisibility(true);
//    frmDashboard.flxPopupLead.forceLayout();
    
    
     
//    }
//   else
//     {
//      frmDashboard.flxIndicators.opacity=1;
//       alert("Sorry there are no tickets to display");
//     }
  
  
   
  
  
}