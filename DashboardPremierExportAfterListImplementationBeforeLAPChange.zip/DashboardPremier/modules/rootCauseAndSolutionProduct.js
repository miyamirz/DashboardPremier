//Type your code here
rootCauseTicketsProduct=[];
rootCausePopupProduct=[];
solutionPopupProduct=[];
var valueRootCauseProduct=0;
var idRootCauseProduct;
function rootCauseProduct()
{
  temp=[];
  if(monthTicketsSolvedProduct.length>0){
   
for(var i=0;i<monthTicketsSolvedProduct.length;i++)
    {
      custName="";
       psAssign="";
      severity="";
       temp.push(monthTicketsSolvedProduct[i].ticketId);
         customArr=monthTicketsSolvedProduct[i].CustomField;
      for(var k=0;k<customArr.length;k++)
      {
//         if(customArr[k].id===22846480)
//           {
//             if(customArr[k].value!==null)
//               {
//                 temp.push(monthTicketsSolvedProduct[i].ticketId);
//               }
            
//           }
        
         if(customArr[k].id===77167)
          {
            severity=customArr[k].value;
            
          }
        else if(customArr[k].id===21277110)
          {
            custName=customArr[k].value;
          }
          
           else if(customArr[k].id===21145230)
          {
            psAssign=customArr[k].value;
          }
        else if(customArr[k].id===21062879)
           {
             custAcc=customArr[k].value;
           }
        
      }
      
       severity=severity.toLowerCase();
      severity=severity.trim();
      if(custName!==null)
      		CustomerName=custName.trim();
      else
            CustomerName="none";
      
          if(custAcc!==null)
      		CustomerAccountName=custAcc.trim();
      else
            CustomerAccountName="none";
      monthTicketsSolvedProduct[i].CAccountName=CustomerAccountName;
      
      PSAssignee=psAssign.trim();
      
             monthTicketsSolvedProduct[i].CName=CustomerName;
             monthTicketsSolvedProduct[i].severityOfTicket=severity;
      
       
      


PSAssignee=PSAssignee.trim();
PSAssignee=PSAssignee.replace("_"," ");
      PSAssignee=PSAssignee.replace("-"," ");
var arr = PSAssignee.split(' ');

var first=arr[0].charAt(0).toUpperCase() + arr[0].slice(1);
if(arr.length>1)
{
var second=arr[1].charAt(0).toUpperCase() + arr[1].slice(1);

if(second!=="Tickets")
{
PSAssignee=first+" "+second;
}
else
{
PSAssignee=first;
}
}
else
{
PSAssignee=first;
}
 if(PSAssignee==="")
    {
      PSAssignee="None";
  }
        monthTicketsSolvedProduct[i].PSAssignee=PSAssignee;
  }
    
  
  rootCauseTicketsProduct=temp;
  
  
  if(rootCauseTicketsProduct.length!==0)
    {
      
        
            idRootCauseProduct=rootCauseTicketsProduct[valueRootCauseProduct];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idRootCauseProduct};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getProductRootCauseCommentsSuccessCallback, getProductRootCauseCommentsErrorCallback);
        
    
  }
  
  else
    {
      frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCProduct.lblRCProduct1.text=0;
      frmDashboard.flxQualityIndicators.flxSolutionList.flxSolProduct.lblSolProduct1.text=0;
      
    }
  
  }
   else
    {
           frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCProduct.lblRCProduct1.text=0;
      frmDashboard.flxQualityIndicators.flxSolutionList.flxSolProduct.lblSolProduct1.text=0;
      
    }
  
}

function invokingToGetRootCauseProductComments(value)
{
   idRootCauseProduct=rootCauseTicketsProduct[value];
           mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
            var operationName = mobileFabricConfiguration.integrationServices[0].operations[3];
          headers={};

          data={"ticketId":idRootCauseProduct};

           mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getProductRootCauseCommentsSuccessCallback, getProductRootCauseCommentsErrorCallback);
}



function getProductRootCauseCommentsSuccessCallback(res)
{
  
  if(res.count!==0)
    {
      flag=0;
      test=0;
      for(var k=0;k<res.comments.length;k++)
        {
            str=res.comments[k].text;
           if(str.indexOf("#Root Cause#") >=0) 
             {
               flag=1;
             }
          if(str.indexOf("#Solution#") >=0 || str.indexOf("#Answer#") >=0) 
             {
               test=1;
             }         
        }
      
      if(flag===0)
        {
           rootCausePopupProduct.push(idRootCauseProduct);
            clRCPopupProduct.push(idRootCauseProduct);
        }
      if(test===0)
        {
           solutionPopupProduct.push(idRootCauseProduct);
            clSolPopupProduct.push(idRootCauseProduct);
        }
    }
  
  valueRootCauseProduct++;
  if(valueRootCauseProduct<rootCauseTicketsProduct.length)
    {
      invokingToGetRootCauseProductComments(valueRootCauseProduct);
    }
  else
    {
      frmDashboard.flxQualityIndicators.flxRootCauseList.flxRCProduct.lblRCProduct1.text=rootCausePopupProduct.length;
      frmDashboard.flxQualityIndicators.flxSolutionList.flxSolProduct.lblSolProduct1.text=solutionPopupProduct.length;
    }
}


function getProductRootCauseCommentsErrorCallback(res)
{
  
 // alert("Error in retreiving comments");
}
//Type your code here