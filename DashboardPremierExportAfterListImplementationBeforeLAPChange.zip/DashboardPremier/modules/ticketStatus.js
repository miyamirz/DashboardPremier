//Type your code here
viewNumTicketStatus=0;
var timerLoad=0;
openCount=0;
pendingCount=0;
solvedCount=0;
var nbCount=0;
escCount=0;
//Negative Feedback views are also included in ticketstatus views

var openCse;
var openProduct;
var openCloud;
var pendingCse;
var pendingProduct;
var pendingCloud;
var solvedCse;
var solvedProduct;
var solvedCloud;
var nfbCse;
var nfbProduct;

var escCse;
var escProduct;
var escCloud;

var openCseInitial;
var openProductInitial;
var openCloudInitial;
var pendingCseInitial;
var pendingProductInitial;
var pendingCloudInitial;
var solvedCseInitial;
var solvedProductInitial;
var solvedCloudInitial;
var nfbCseInitial;
var nfbProductInitial;
var escCseInitial;
var escProductInitial;
var escCloudInitial;


viewArrTicketStatus=["114115504214","114115352713","114115351973","114115351093","114115352733","114115351993","114115351953","114115506394","114115352013","114117060174","114116936113","114128747673","114129276453","114129277213"];
mobileFabricConfiguration = {
    appKey: "13f4e65125c64d418210ea66635e3352",
    appSecret: "2d07b5021ec6e5079cdb8c8685ba95de",
    serviceURL: "https://productsupport.konylabs.net/authService/100000002/appconfig",
    
    integrationServices: [{
        service: "zendeskConnect",
        operations: ["opencountTotal","ticketInfo","comments","TraverseComments","solvedMTTR"]
    },{
        service:"GraphsData",
        operations:["graphinputs_update","graphinputs_read"]
    },{
        service:"CustomerList",
        operations:["readCustList"]
    }],
    
    konysdkObject: null,
    authClient: null,
    integrationObj: null,
    integrationObj1:null,
    isKonySDKObjectInitialized: false,
    isMFAuthenticated: false
};

function mobileFabricInitialization() {
    if (!mobileFabricConfiguration.isKonySDKObjectInitialized) {
        initializeMobileFabric();
    } else if (mobileFabricConfiguration.isKonySDKObjectInitialized) {
        getResponse(viewArrTicketStatus[viewNumTicketStatus]);
    }
    
}

function initializeMobileFabric() {
    kony.print(" ********** Entering into initializeMobileFabric ********** ");
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        kony.application.showLoadingScreen("loadSkin", "Init!!!", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {
            enableMenuKey: true,
            enableBackKey: true,
          shouldShowLabelInBottom: "true",
            progressIndicatorColor: "ffffff77"
        });
        mobileFabricConfiguration.konysdkObject = new kony.sdk();
        mobileFabricConfiguration.konysdkObject.init(mobileFabricConfiguration.appKey, mobileFabricConfiguration.appSecret, mobileFabricConfiguration.serviceURL, initializeMobileFabricSuccess, initializeMobileFabricFailure);
    } else //alert("Network unavailable. Please check your network settings. ");
    kony.print(" ********** Exiting out of initializeMobileFabric ********** ");
}

function initializeMobileFabricSuccess(response) {
    kony.print(" ********** Entering into initializeMobileFabricSuccess ********** ");
    kony.print(" ********** Success initializeMobileFabricSuccess response : " + JSON.stringify(response) + " ********** ");
    mobileFabricConfiguration.isKonySDKObjectInitialized = true;
    kony.application.dismissLoadingScreen();
   getResponse(viewArrTicketStatus[viewNumTicketStatus]);
  
   getLeadIndicatorResponse(viewArrLeadIndicator[viewNumLead]);
  
  solvedTicketsForMonth();
  
  getCustList();
  
  
  //solvedMTTR();
  
  
   
   // authenticateMFUsingUserStore();
    kony.print(" ********** Exiting out of initializeMobileFabricSuccess ********** ");
}

function initializeMobileFabricFailure(error) {
    kony.print(" ********** Entering into initializeMobileFabricFailure ********** ");
    kony.print(" ********** Failure in initializeMobileFabric: " + JSON.stringify(error) + " ********** ");
    kony.application.dismissLoadingScreen();
    //alert(" Unable to initialize the application. Please try again. ");
    kony.print(" ********** Exiting out of initializeMobileFabricFailure ********** ");
}

function getResponse(viewIdHere) {
  if(timerLoad!==1){  
frmDashboard.flxIndicators.opacity=0.1;
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        kony.application.showLoadingScreen("loadSkin","", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, false, true, {
            enableMenuKey: true,
            enableBackKey: true,
          shouldShowLabelInBottom: "true",
            progressIndicatorColor: "ffffff77"
        });
    }
  }
        mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
        var operationName = mobileFabricConfiguration.integrationServices[0].operations[1];
      headers={};
     
      data={"viewId":viewIdHere};
      
       mobileFabricConfiguration.integrationObj.invokeOperation(operationName, headers, data, getResponseSuccessCallback, getResponseErrorCallback);
        
    
 }

function getResponseSuccessCallback(res)
{
  //kony.application.dismissLoadingScreen();
// console.log("i:"+viewNumTicketStatus);
//   console.log(res);
  switch(viewNumTicketStatus)
    {
      case 0:     
                  openCse=res;
                  openCseInitial=res;
                  if(res.ticketsCount!==null && res.ticketsCount!=="null"){
                        frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO1.lblO12.text=res.ticketsCount;
                        openCount=parseInt(res.ticketsCount);
                        }
                  else
                    {
                      frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO1.lblO12.text="-";
                      openCount=0;
                    }                
                break;
      case 1:   
               openProduct=res;
               openProductInitial=res;
              if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO2.lblO22.text=res.ticketsCount;
               openCount+=parseInt(res.ticketsCount);
                 }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO2.lblO22.text="-";
                   openCount+=0;
                  }
                 
                break;        
       case 2:   
              openCloud=res;
              openCloudInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO3.lblO32.text=res.ticketsCount;
                openCount+=parseInt(res.ticketsCount);
               frmDashboard.flxOpen.lblOpenCount.text=openCount;
                }
                else
                  {
                     frmDashboard.flxIndicators.flxTicketStatus.flxOpenList.flxO3.lblO32.text="-";
                openCount+=0;
             frmDashboard.flxOpen.lblOpenCount.text=openCount;
                  }
                break;       
      case 3:   
                pendingCse=res;
                pendingCseInitial=res;
              if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP1.lblP12.text=res.ticketsCount;
                 pendingCount+=parseInt(res.ticketsCount);
              }
               else
                 {
                        frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP1.lblP12.text="-";
                 pendingCount+=0;
                 }
                break;        
  	case 4:   
                pendingProduct=res;
                pendingProductInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP2.lblP22.text=res.ticketsCount;
                  pendingCount+=parseInt(res.ticketsCount);
               }
              else
                {
                   frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP2.lblP22.text="-";
                  pendingCount+=0;
                }
                break;        
   case 5:   
                 pendingCloud=res;
                  pendingCloudInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP3.lblP32.text=res.ticketsCount;
                pendingCount+=parseInt(res.ticketsCount);
                frmDashboard.flxPending.lblPendingCount.text=pendingCount;
               }
                else
                  {
                    frmDashboard.flxIndicators.flxTicketStatus.flxPendingList.flxP3.lblP32.text="-";
                pendingCount+=0;
              frmDashboard.flxPending.lblPendingCount.text=pendingCount;
                    
                  }
                break;       
   case 6:   
        
              solvedCse=res;
              solvedCseInitial=res;
              rootCauseCse();
              if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS1.lblS12.text=res.ticketsCount;
                    solvedCount+=parseInt(res.ticketsCount);
              }
              else
                {
                  frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS1.lblS12.text="-";
                    solvedCount+=0;
                }
                 
  
                break; 
 case 7:    
             solvedProduct=res;
             solvedProductInitial=res;
              rootCauseProduct();
             if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS2.lblS22.text=res.ticketsCount;
                 solvedCount+=parseInt(res.ticketsCount);
               
               
               
              }
        else
          {
                frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS2.lblS22.text="-";
                 solvedCount+=0;
          }
                
               break; 
  case 8:   
                solvedCloud=res;
                solvedCloudInitial=res;
             if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS3.lblS32.text=res.ticketsCount;
                  solvedCount+=parseInt(res.ticketsCount);
               frmDashboard.flxSolved.lblSolvedCount.text=solvedCount;
             }
             else
               {
                  frmDashboard.flxIndicators.flxTicketStatus.flxSolvedList.flxS3.lblS32.text="-";
                  solvedCount+=0;
                  frmDashboard.flxSolved.lblSolvedCount.text=solvedCount;
               }
                console.log("Successfully finished with TICKET STATUS TAB");
                getGraphData();
        
                
                break; 
      case 9:   
               nfbCse=res;
               nfbCseInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               nbCount+=parseInt(res.ticketsCount);
               frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB0.lblNFB02.text=res.ticketsCount;
               }
                else
                  {
                    nbCount+=0;
                  }
                break; 
     case 10:    
             nfbProduct=res;
              nfbProductInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
                nbCount+=parseInt(res.ticketsCount);
               frmDashboard.flxIndicators.flxLagIndicator.flxNFBList.flxNFB1.lblNFB12.text=res.ticketsCount;
               frmDashboard.flxLagIndicator.flxNegativeFeedback.lblNFBCount.text=nbCount;
               nbCount=0;
               }
                  else
                    {
                      frmDashboard.flxLagIndicator.flxNegativeFeedback.lblNFBCount.text="---";
                      nbCount=0;
                    }
                break; 
        
      case 11:     
                   
                  escCse=res;
                  escCseInitial=res;
                if(res.ticketsCount!==null && res.ticketsCount!=="null"){
                      frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCse.lblESCCse1.text=res.ticketsCount;
                      escCount=parseInt(res.ticketsCount);
                      }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCse.lblESCCse1.text="-";
                      escCount=0;
                  }
                break;
      case 12:   
               escProduct=res;
                escProductInitial=res;
              if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsProduct.lblESCProduct1.text=res.ticketsCount;
               escCount+=parseInt(res.ticketsCount);
                 }
                else
                  {
                    frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsProduct.lblESCProduct1.text="-";
                   escCount+=0;
                  }
                break;        
       case 13:   
              escCloud=res;
              escCloudInitial=res;
               if(res.ticketsCount!==null && res.ticketsCount!=="null"){
               frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCloud.lblESCCloud1.text=res.ticketsCount;
                escCount+=parseInt(res.ticketsCount);
               frmDashboard.flxIndicators.flxLagIndicator.flxEscalations.lblEscalationsCount.text=escCount;
                 
                }
                else
                  {
                     frmDashboard.flxIndicators.flxLagIndicator.flxEscalationsList.flxEscalationsCloud.lblESCCloud1.text="-";
                escCount+=0;
             frmDashboard.flxIndicators.flxLagIndicator.flxEscalations.lblEscalationsCount.text=escCount;
                  }
                break;  
    }
  
  viewNumTicketStatus++;
  if(viewNumTicketStatus<viewArrTicketStatus.length)
  getResponse(viewArrTicketStatus[viewNumTicketStatus]);
  
  
}
function getResponseErrorCallback(res)
{
  //alert("Errror in retrieving response");
  frmDashboard.flxIndicators.opacity=1;
}