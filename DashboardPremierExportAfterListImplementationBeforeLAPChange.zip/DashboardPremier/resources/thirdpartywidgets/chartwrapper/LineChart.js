 LineChart = {

    initializeWidget : function(parentNode, widgetModel)
    {
      
                  console.log("initializing  NOW...");
                  console.log(parentNode);
                  console.log(widgetModel);
				  
				           var area='<div id="canvas_bademiya" style="width:100%;height:100%"><canvas id="canvas" width="500px" height="120px"></canvas>  </div>'; 

							parentNode.innerHTML=area;
				  
	// function drawChart(){		  
		// var options = {
  // type: 'line',
  // data: {
    // labels: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday","Sunday"],
    // datasets: [
	    // {
	      // label: 'Created',
		  // lineTension: 1,
            // backgroundColor: "rgba(75,192,192,0.3)",
            // borderColor: "rgba(75,192,192,1)",
            // borderCapStyle: 'round',
            // borderDash: [],
            // borderDashOffset: 0.0,
            // pointBorderColor: "rgba(75,192,192,1)",
            // pointBackgroundColor: "#fff",
            // pointBorderWidth: 1,
            // pointHoverRadius: 5,
            // pointHoverBackgroundColor: "rgba(75,192,192,1)",
            // pointHoverBorderColor: "rgba(220,220,220,1)",
            // pointHoverBorderWidth: 2,
            // pointRadius: 5,
            // pointHitRadius: 10,
	      // data: [0,0,0,0,0,0,0],
      	// borderWidth: 3
    	// },
	    // {
	      // label: 'Solved',
		  // lineTension: 1,
            // backgroundColor: "rgba(130,169,76,0.4)",
            // borderColor: "rgba(130,169,76,1)",
            // borderCapStyle: 'round',
            // borderDash: [],
            // borderDashOffset: 0.0,
            // pointBorderColor: "rgba(75,192,192,1)",
            // pointBackgroundColor: "#fff",
            // pointBorderWidth: 1,
            // pointHoverRadius: 5,
            // pointHoverBackgroundColor: "rgba(75,192,192,1)",
            // pointHoverBorderColor: "rgba(220,220,220,1)",
            // pointHoverBorderWidth: 2,
            // pointRadius: 5,
            // pointHitRadius: 10,
	      // data: [0,0,0,0,0,0,0],
      	// borderWidth: 3
    	// }
		
		// ]
  // },
  // options: { 
        // legend: {
            // labels: {
                // fontColor: "#ddd",
                // fontSize: 10
            // }
        // },
        // scales: {
            // yAxes: [{
                // ticks: {
                    // fontColor: "#ddd",
                    // fontSize: 12,
                    
                    // beginAtZero: true
                // }
            // }],
            // xAxes: [{
                // ticks: {
                    // fontColor: "#ddd",
                    // fontSize: 10,
                   
                    // beginAtZero: true
                // }
            // }]
        // }
    // }
// }

// var ctx = document.getElementById('canvas').getContext('2d');
// new Chart(ctx, options);
	// }
	// drawChart();
    }   
}