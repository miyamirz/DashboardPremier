function AS_Button_d6ad25737adb44af86d5aefccc24cb18(eventobject) {
    frmDashboard.flxPopup.setVisibility(false);
}