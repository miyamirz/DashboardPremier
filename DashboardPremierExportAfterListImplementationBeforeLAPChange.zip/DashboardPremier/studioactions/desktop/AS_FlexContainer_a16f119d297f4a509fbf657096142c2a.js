function AS_FlexContainer_a16f119d297f4a509fbf657096142c2a(eventobject) {
    if (frmDashboard.flxNFBList.isVisible) {
        frmDashboard.flxNFBList.setVisibility(false);
    } else {
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(true);
    }
}