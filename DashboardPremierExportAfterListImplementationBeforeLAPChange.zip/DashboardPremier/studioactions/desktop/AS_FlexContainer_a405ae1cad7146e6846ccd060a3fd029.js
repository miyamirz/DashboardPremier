function AS_FlexContainer_a405ae1cad7146e6846ccd060a3fd029(eventobject) {
    if (frmDashboard.flxRBList.isVisible) frmDashboard.flxRBList.setVisibility(false);
    else {
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(false);
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(true);
    }
}