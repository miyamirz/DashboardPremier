function AS_FlexContainer_a8afb219d47348b487fcb1ea1234a523(eventobject) {
    return navigateToView.call(this, eventobject);
}