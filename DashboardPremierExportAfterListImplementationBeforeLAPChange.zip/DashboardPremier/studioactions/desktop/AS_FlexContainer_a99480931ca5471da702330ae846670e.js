function AS_FlexContainer_a99480931ca5471da702330ae846670e(eventobject) {
    if (frmDashboard.flxPendingList.isVisible) frmDashboard.flxPendingList.setVisibility(false);
    else frmDashboard.flxPendingList.setVisibility(true);
}