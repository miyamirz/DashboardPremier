function AS_FlexContainer_aae79fb09a8847dba8b651820f6c77d0(eventobject) {
    if (frmDashboard.flxMttrList.isVisible) frmDashboard.flxMttrList.setVisibility(false);
    else {
        frmDashboard.flxFirstResBreachedList.setVisibility(false);
        frmDashboard.flxRBList.setVisibility(false);
        frmDashboard.flxNFBList.setVisibility(false);
        frmDashboard.flxMttrList.setVisibility(true);
    }
}