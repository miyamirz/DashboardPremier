function AS_FlexContainer_ac807ce47d804f6a9d4eb48cac6e45d2(eventobject) {
    return navigateToView.call(this, eventobject);
}